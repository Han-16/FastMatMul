# zkMaP 논문 재현 구현 계획

- 작성일: 2026-09-30
- 목표: 로컬 Go 구현, 동작 테스트, LAMP·zkMatrix 비교 실험을 위한 실행 인터페이스 준비.
- 우선순위: 구현 및 테스트. 이번 단계에서 서버의 대규모 실험은 실행하지 않는다.
- 기본 원본 경로의 기준: 논문의 절차·수식을 재현한다. soundness·zero knowledge 확보를 완료 조건으로 요구하지 않으며, 검증식을 임의로 보완하지 않는다.
- **2026-10-01 추가 요청:** completeness 실패 부분의 수정을 허용했다. 원본 경로를 보존하고 `completeness-roots-v1` 수정 경로를 별도로 추가한다. soundness/zero knowledge 보완 및 서버/성능 실험은 범위 밖이다. 로컬에서는 작은 입력의 기능 테스트만 한다.

## 1. 기준 자료와 구현 위치

- 원문: `Revision/zkMaP.pdf` (38쪽), DOI `10.62056/angy11fgx`.
- PDF SHA-256: `43e9631792b3c6124e58f081c11073113d779794e1fb0d4ab97aa5cac99ceaec`.
- 기준 알고리즘: Section 4.1–4.4, Appendix E Algorithm 2, Appendix F Algorithm 3. 서로 다른 검증식을 하나로 합치지 않는다.
- 참고 구현: `Benchmark/m1/source/measured/comparison-source.tar.gz` 안의 LAMP·zkMatrix. 기존 측정 소스는 읽기 전용으로 보존한다.
- 새 코드: `Implementation/zkmap/`. 독립 Go 모듈로 작성하여 기존 논문·실험을 변경하지 않는다.
- 곡선과 라이브러리: 비교 구현과 같은 BN254, 같은 gnark-crypto 버전. Groth16 회로를 추가하지 않는다.

## 2. 기본 원본 경로의 구현 원칙

1. 논문에서 정의한 행렬 row-major 인코딩, SRS, challenge, projection, witness 나눗셈을 실제 유한체·곡선 연산으로 구현한다.
2. 보간 노드, hash 및 직렬화처럼 명시되지 않은 선택은 이름을 붙여 설정·문서·결과에 남긴다. 기본값과 대안의 차이를 테스트한다.
3. Appendix E의 점 덧셈/뺄셈 검증식과 Section 4.4의 명시적인 scalar-evaluation 검증식은 별도 경로로 재현한다. G1 점끼리의 정의되지 않은 곱을 임의의 연산으로 대체하지 않는다.
4. `W(X)=(mu-Pay(X)Pby(X))/(X-y)`의 나머지가 0이 아니면 정확한 witness 다항식이 존재하지 않는다. 나머지를 버려 성공 증명으로 보고하지 않는다.
5. 정상 입력에서도 증명 생성이나 검증이 실패할 수 있다. 실패를 원시 결과로 기록하며 구현 버그, 해석 의존 실패, 명세 미정의를 구분한다.
6. 논문에 없는 linking proof, hiding randomizer, SNARK, batch 보정식은 추가하지 않는다. 저자의 구현 재현 또는 보완된 프로토콜이라는 주장을 하지 않는다.

## 3. 작업 순서

### P0. 원문과 비교 조건 확인

- [x] 관련 PDF 페이지를 추출하고 수식을 시각적으로 확인한다.
- [x] 알고리즘 각 단계와 코드 함수의 대응표를 만든다.
- [x] Appendix E/F, 압축, 직렬화의 해석 선택 및 구현 불가능한 부분을 기록한다.
- [x] Section 7의 목표 크기·조건을 아래에 정리한다.

### P1. 단일 행렬곱 구현

- [x] 유한체 행렬, 독립 곱 계산, row-major 다항식, KZG SRS/commitment.
- [x] public parameters 및 A/B/C commitment에서 challenge 재구성.
- [x] structured projection, projection 보간, 다항식 곱, 정확한 witness 나눗셈.
- [x] Appendix E 검증식 및 Section 4.4 scalar 식.
- [x] canonical statement/proof 직렬화 및 decode 후 재검증.
- [x] Section 4.3의 정의 가능한 압축 연산과 최종 commitment의 명세 경계를 기록.

### P2. 배치 및 실행 인터페이스

- [x] 독립 행렬곱 q개에 대해 개별 증명 생성·실패를 기록한다.
- [x] Appendix F의 명시 가능한 aggregation/challenge/pairing 계산을 재현하고, 정의되지 않은 G1 곱의 처리를 명시한다.
- [x] `-K`, `-batch`, `-repetitions`, `-threads`, `-seed`, `-max-matrix-elements`, `-output` 인터페이스.
- [x] setup, 행렬곱, commitment, prove, verify 시간 및 proof/statement 실제 bytes를 각각 기록한다.
- [x] 실패·미정의 결과를 성공 벤치마크와 구분하는 JSONL 출력과 종료 코드.
- [x] 서버 실행 계획 생성 및 실제 실행 스크립트. 기본 동작은 계획 출력이며 대규모 실행은 명시적 옵션으로 선택한다.

### P3. 테스트 및 결과 문서

- [x] projection 값과 실제 행렬곱의 scalar identity를 독립 계산으로 확인한다.
- [x] 보간 round-trip, 다항식 곱, 나눗셈 항등식 및 나머지.
- [x] 실제 curve pairing 검증, 입력/증명 변경, canonical serialization 검증.
- [x] 소규모 정상 실행과 일반 정상 입력의 실패 경로를 테스트한다. 의도한 실패를 테스트 통과와 혼동하지 않는다.
- [x] batch aggregation 계산과 원문의 식이 수락하는지 여부를 별도 확인한다.
- [x] 전체 Go 테스트 및 CLI smoke test, 가능하면 Section 7 최소 크기 128의 1회 로컬 실행.
- [x] 실행 명령·환경·소스 fingerprint·테스트 결과를 보존하고 이 계획의 진행 상태를 갱신한다.

## 4. Section 7 실험 목표

`Paper/Contents/evaluation.tex`와 `Paper_original/Contents/evaluation.tex`의 조건을 기준으로 한다. 기존 서버 설정 일부가 k=4096까지라는 이유로 논문의 k=8192 목표를 삭제하지 않는다.

| 항목 | 목표 |
| --- | --- |
| 정방행렬 | k=2^7,...,2^13 (128,256,512,1024,2048,4096,8192) |
| 배치 | k=128, 독립 행렬곱 q=1,...,10 |
| 반복 | 설정마다 10회 |
| 서버 | 동일 서버, 32 threads; CPU/RAM/OS/Go 실제 값을 기록 |
| 곡선 | BN254 |
| LAMP 고유 설정 | rho=1/2, t=309. zkMaP에는 대응되는 code rate/query count가 없으므로 메타데이터에만 보존하고 가짜 연산을 넣지 않음 |
| 측정 | setup 별도, 행렬곱 별도, commitment 포함 online prove, verify, 실제 proof 및 statement bytes |
| 추가 workload | Section 7의 GPT-2: sequence 1024, 36개 곱. 정확한 shape와 공유값·연결 관계 확인이 필요하며 정방행렬·batch 구현 뒤 별도 단계로 둠 |

128~8192 크기의 메모리·시간 사용은 서버에서 확인한다. 로컬 테스트는 작은 크기를 사용한다. 실패한 시도에도 시간은 남기되 정상 proof 생성/검증 성능으로 집계하지 않는다. 정확한 witness가 일반 입력에서 만들어지지 않는다면 서버 실험은 그 실패를 그대로 재현하는 단계이며 성공 성능 표를 만들 수는 없다.

## 5. 완료 판단

- **구현/테스트 완료:** 명시된 식의 재현 코드, 해석 기록, 단일/배치 실행 인터페이스, 직렬화, 테스트, 원시 실행 기록이 존재한다. 명세 미정의 부분은 구체적으로 식·페이지와 함께 표시한다.
- **정상 동작 여부:** 정상 일반 입력에서 witness 생성과 검증이 실제 성공했는지 별도 보고한다. 테스트 스위트 통과만으로 정상 동작한다고 말하지 않는다.
- **성능 비교 준비:** 정상 실행이 가능하고 측정 범위가 맞는 경우에만 성공 결과를 기존 LAMP·zkMatrix와 비교한다. 수정 없이 실행되지 않는 부분은 실패 기록으로 남긴다.
- 논문 본문, 서버 운영 상태, 기존 측정 자료는 이번 작업에서 변경하지 않는다.

## 6. 현재 진행 상황

### 2026-10-01 completeness 수정판

- [x] 단위근 보간의 내적을 표현하는 `n Pay Pby − mu = Q(X)(X^n−1)+X T(X)` 항등식과 completeness 근거를 작성한다.
- [x] G2 SRS 확장, 새로운 single witness/pairing 식을 별도 API로 구현한다.
- [x] 같은 항등식의 weighted product pairing batch를 구현하고 원본의 weighted-y 식과 구분한다.
- [x] 별도 proof marker/직렬화와 CLI variant, 결과 metadata를 구현한다.
- [x] n=2,4,8, 여러 seed와 q=1,2,3에서 실제 생성/검증/decode 재검증을 테스트한다.
- [x] 최종 로그 및 작은 CLI 실행 기록을 `test-results/20261001/`에 보존한다.
- Go 최상위 테스트 21개와 Python 테스트 3개 통과. random 4×4 단일 및 q=3 배치의 수정판 CLI 실행에서 생성·검증·decode 재검증 모두 성공했다. 같은 크기의 원본 경로는 기존 witness 실패를 유지했다. macOS/Linux amd64 빌드도 성공했다.
- 수식/변경 범위: `Implementation/zkmap/COMPLETENESS_REPAIR.md`. 원문 성능의 재현으로 사용하지 않는다. server 실험은 하지 않는다.

### 2026-09-30 원본 재현 기록

- 계획 작성 및 명시된 식 재현 구현·테스트 완료. 구현: `Implementation/zkmap/`.
- 실행 방법·식 대응·명세 경계: `Implementation/zkmap/README.md`.
- 테스트 결과: `Implementation/zkmap/test-results/20260930/RESULTS.md`; 원시 JSONL 6건과 실행 manifest 및 Go/Python 로그 보존.
- Go 최상위 테스트 14개, Python 실행 계획/제어 테스트 3개 통과. macOS 빌드 및 Linux amd64 cross-build 성공.
- 정상 random 입력은 기본 roots 보간 128×128에서도 witness의 나머지가 0이 아니어 proof 생성 실패. 작은 random 입력은 integer 보간 및 coefficient 해석에서도 실패한다. 올바른 행렬곱 projection identity는 별도로 확인했다.
- zero/sparse exceptional 입력으로 실제 증명 생성·pairing·직렬화 재검증 성공 경로를 확인했다. 일반 입력 성공을 의미하지 않는다.
- literal Appendix F는 G1 곱 미정의를 오류로 반환한다. scalar 해석의 배치 계산은 별도 진단 옵션으로만 제공한다. 압축은 Eq. (15)까지만 구현하고 outer commitment의 미정의 연산은 문서화했다.
- Section 7 정방행렬/배치 목표 17개 명령 생성 완료. 대규모 서버 실행은 하지 않았다. GPT-2는 36개 shape 목록만 제공하며 executable 구현은 후속 단계다.
- 체크 완료는 해당 구현·테스트·명세 경계 기록을 완료했다는 뜻이다. **일반 입력이 정상 수락되는 zkMaP 전체 구현 또는 성공 성능 비교 준비가 완료되었다는 뜻은 아니다.**
