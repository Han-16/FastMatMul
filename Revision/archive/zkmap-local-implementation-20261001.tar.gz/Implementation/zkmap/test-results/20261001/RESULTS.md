# 2026-10-01 completeness 수정판 로컬 테스트

## 결과

`completeness-roots-v1`의 작은 일반 정상 입력에서 증명 생성·pairing 검증·canonical encode/decode 후 재검증이 성공했다. 기본 `paper` 경로의 기존 실패는 유지했다. 서버 및 성능 실험은 하지 않았다.

- Go 최상위 테스트 21개 통과 (기존 14개 + 추가 7개). 실제 정상 입력 크기 n=2,4,8, input seed=1,7,19를 사용했다.
- weighted batch는 q=1,2,3 및 rho=0,1,7을 테스트했다. 이 테스트는 함수 동작 확인이며 반복 성능 측정이 아니다.
- Python 실행 계획·제어 테스트 3개 통과. 기존 server profile은 기본 원본 설정을 유지한다. subprocess 실행 제어 테스트는 mock을 사용한다.
- macOS amd64 빌드 및 Linux amd64 cross-build 성공. Linux 바이너리는 서버에서 실행하지 않았다.
- 직접 CLI 실행은 모두 n=4, 2 threads, 1회다. matrix 생성은 full-field random이고 zero fixture가 아니다.

| CLI 기록 | variant | 결과 |
| --- | --- | --- |
| `complete-small.jsonl` | completeness-roots-v1 | single 증명 생성·검증·decoded 검증 성공; payload 196B |
| `complete-batch-small.jsonl` | completeness-roots-v1 | 독립 3개 곱 batch 생성·검증·decoded 검증 성공; payload 392B |
| `paper-small.jsonl` | paper | witness_remainder_nonzero; proof 미생성, verifier 미실행 |

원시 로그는 `go-tests.log`, `profile-tests.log`이며 명령/소스/바이너리 fingerprint는 `manifest.json`에 둔다. 일부 unit tests와 CLI 기능 테스트는 겹쳐 실행되었으므로 기록된 시간은 비교 성능 수치로 사용하지 않는다.

## 수정 범위와 completeness 근거

수정한 핵심 식은 다음과 같다.

`n Pay(X)Pby(X) − mu = Q(X)(X^n−1) + X T(X)`.

단위근 보간에서 정상 projection의 내적은 product polynomial의 차수 0,n 계수 합에 n을 곱한 값이다. 따라서 이 나눗셈의 상수 remainder가 항상 0이며, 새로운 pairing 식도 정상 입력에 대해 성립한다. 테스트는 다항식 항등식을 여러 점에서 독립 계산하여 확인하고, 실제 curve verification까지 수행한다.

정상 입력 수락은 원래 행렬 commitment와 projection의 연결 검사를 보완했다는 뜻이 아니다. 새 verifier도 해당 연결이나 degree/hiding을 보장하지 않는다. 원문 zkMaP의 성능 또는 보안성 재현으로 취급하지 않는다. 변경된 SRS/검증/배치 비용과 수식 도출은 `../../COMPLETENESS_REPAIR.md`에 기록했다.
