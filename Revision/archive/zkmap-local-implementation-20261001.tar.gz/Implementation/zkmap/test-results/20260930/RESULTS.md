# 2026-09-30 로컬 구현 테스트 결과

## 결론

논문의 명시된 연산을 재현하는 Go 코드, 단일/배치 실행 인터페이스와 Section 7 실행 계획을 만들었다. **일반 정상 행렬곱 입력에서는 현재 세 가지 인코딩 해석으로 정확한 witness를 만들 수 없다.** 따라서 정상 proof 생성·검증이 가능한 성능 비교 구현이 완료되었다고 주장하지 않는다.

이 결과는 soundness/zero knowledge를 구현 완료 조건으로 요구해서 발생한 제한이 아니다. 원문의 prover 식을 실행하는 과정에서 발생한 대수적 실패다. 원저자의 완전한 구현이나 다른 미지의 인코딩에 대한 결론은 아니다.

## 확인한 범위

- Go 테스트: 14개 최상위 테스트 통과 (내부 인코딩별 subtest 포함). 행렬곱/projection의 독립 대조, 보간 round-trip, NTT와 직접 다항식 곱의 대조, 나눗셈 항등식, 실제 pairing, wire decode 후 검증, 입력 변경, 파일 덮어쓰기 방지, 실패 상태 보존을 확인했다.
- Python 테스트: 3개 통과. Section 7 크기/반복/threads 일치, preflight 실패 시 큰 작업 미실행, 명시적 실패 재현 선택 시 17개 목표 보존을 확인했다. 실행 제어 테스트는 subprocess를 mock하며 실제 대규모 실험을 실행하지 않는다.
- macOS amd64 바이너리 빌드 성공. Linux amd64 cross-build 성공. Linux 바이너리는 서버에서 실행하지 않았다.
- Go 1.25.6, 현재 로컬 실행의 `runtime.NumCPU=10`, CLI smoke에는 2 threads를 사용했다. CPU 모델 및 RAM 조회는 로컬 sandbox에서 확보되지 않아 원시 metadata에 unknown/null로 남아 있다.

## 실제 CLI smoke 결과

| 입력·설정 | 상태 | 의미 |
| --- | --- | --- |
| 정상 random 128×128, roots 보간 | witness_remainder_nonzero, exit 2 | 행렬곱 projection identity는 일치하지만 정확한 W(X)가 없음 |
| 정상 random 4×4, integer 보간 | witness_remainder_nonzero, exit 2 | 선택한 보간 해석에서 witness 생성 실패 |
| 정상 random 4×4, coefficient 해석 | witness_remainder_nonzero, exit 2 | coefficient 해석에서도 witness 생성 실패 |
| zero 4×4, Appendix E | verified, exit 0 | 생성/검증/직렬화/재검증의 fixture 성공 |
| zero 4×4 q=3, literal batch | batch_aggregation_failed, exit 2 | G1 점의 곱 미정의 지점까지 도달 |
| zero 4×4 q=3, scalar batch 진단 | verified, exit 0 | 별도 식 해석의 fixture 성공; 일반 batch 성공 주장이 아님 |

일부 CLI smoke 및 unit tests는 동시에 실행했다. 기록된 시간은 기능 확인용이며 성능 비교에 사용하지 않는다. 실제 명령·종료 코드·소스/바이너리 hash는 `manifest.json`, 원시 상태 및 나머지는 각 JSONL, 테스트 로그는 `go-tests.log`, `profile-tests.log`에 보존했다.

nonzero exceptional 입력도 Go 테스트에서 확인했다. coefficient 해석의 sparse A/B에서 정확한 quotient가 존재하고 본문의 scalar 식은 수락하지만, Appendix E의 뺄셈 식은 A/B 값에 따라 다른 결과를 낸다. 따라서 zero 성공 사례만으로 verifier를 검사하지 않았다.

## 일반 입력이 실패하는 이유

실제 행렬곱으로부터 계산한 projection은 다음을 만족한다.

`mu = Σ_k ay[k] by[k]`.

반면 Appendix E의 W(X)가 다항식이 되려면 다음이 필요하다.

`mu = Pay(y) Pby(y)`.

보간 또는 일반 coefficient 인코딩은 두 번째 등식을 첫 번째 등식으로부터 자동으로 얻지 못한다. 구현은 synthetic division의 실제 나머지 `mu−Pay(y)Pby(y)`를 보존하고 0이 아니면 proof를 반환하지 않는다. remainder를 버려 quotient만 commitment하거나 trapdoor s에서 rational expression을 평가하는 변경은 하지 않았다.

## 이후 실험 범위

- `section7-plan.json`: 정방행렬 k=128~8192, 배치 k=128/q=1~10, 각 10회·32 threads의 17개 명령. 실제 실행은 없다.
- 이 상태에서 서버 성공 성능 표를 만들 수는 없다. 현재 해석의 실패 재현은 실행할 수 있다.
- 압축의 outer group-polynomial evaluation과 literal batch G1 곱에는 원문에서 필요한 연산 정의가 빠져 있다. 위치와 구현 범위는 `../../README.md`에 기록했다.
- GPT-2는 원래 workload 36개의 shape만 계획에 포함했다. executable rectangular/graph 구현은 아직 없다.
- 추가 인코딩 명세를 확보하거나 구현 기준을 변경하면, 기존 실패 기록을 보존하고 별도 변경으로 이어간다.
