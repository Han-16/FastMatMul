package zkmap

import (
	"errors"
	"github.com/consensys/gnark-crypto/ecc/bn254/fr"
	"math/big"
	"math/rand"
	"testing"
)

func completeTestParams(t *testing.T, n int) *CompleteParams {
	t.Helper()
	base := testParams(t, n, Roots)
	p, e := completeParamsFromSRS(n, base.srs, big.NewInt(17))
	if e != nil {
		t.Fatal(e)
	}
	return p
}

func TestConcreteCompletenessCounterexampleAndCorrectedIdentity(t *testing.T) {
	a := matrix(2, 2, 1, 0, 0, 1)
	projection, e := Project(a, a, a, field(2))
	if e != nil {
		t.Fatal(e)
	}
	if projection.Mu.String() != "9" || !projection.Mu.Equal(&projection.InnerProduct) {
		t.Fatal("independent matrix identity failed")
	}
	pay, e := EncodeProjection(projection.A, Roots)
	if e != nil {
		t.Fatal(e)
	}
	pby, e := EncodeProjection(projection.B, Roots)
	if e != nil {
		t.Fatal(e)
	}
	av, bv := Evaluate(pay, field(2)), Evaluate(pby, field(2))
	var remainder, product fr.Element
	product.Mul(&av, &bv)
	remainder.Sub(&projection.Mu, &product)
	var want fr.Element
	want.SetUint64(4).Inverse(&want)
	want.Mul(&want, ptrField(37))
	if !remainder.Equal(&want) {
		t.Fatal("expected original remainder 37/4")
	}
	numerator := PolynomialProduct(pay, pby)
	n := field(2)
	for i := range numerator {
		numerator[i].Mul(&numerator[i], &n)
	}
	numerator[0].Sub(&numerator[0], &projection.Mu)
	q, r, e := DivideByVanishing(numerator, 2)
	if e != nil || !r[0].IsZero() {
		t.Fatal("corrected constant remainder nonzero")
	}
	for _, x := range []uint64{0, 1, 2, 7} {
		point := field(x)
		left := Evaluate(numerator, point)
		right := Evaluate(q, point)
		vanish := field(x * x)
		one := field(1)
		vanish.Sub(&vanish, &one)
		right.Mul(&right, &vanish)
		tail := Evaluate(r, point)
		right.Add(&right, &tail)
		if !left.Equal(&right) {
			t.Fatal("new identity mismatch")
		}
	}
}
func ptrField(v uint64) *fr.Element { e := field(v); return &e }

func TestCompletenessRandomHonestInputsAndDecodedPayload(t *testing.T) {
	for _, n := range []int{2, 4, 8} {
		p := completeTestParams(t, n)
		for _, seed := range []int64{1, 7, 19} {
			random := rand.New(rand.NewSource(seed))
			a, b := RandomMatrix(random, n, n), RandomMatrix(random, n, n)
			c, e := Multiply(a, b)
			if e != nil {
				t.Fatal(e)
			}
			s, e := CommitMatrices(p.Base(), a, b, c)
			if e != nil {
				t.Fatal(e)
			}
			proof, trace, e := ProveComplete(p, s, a, b, c)
			if e != nil {
				t.Fatalf("n=%d seed=%d: %v", n, seed, e)
			}
			if !trace.ConstantRemainder.IsZero() || !trace.Mu.Equal(&trace.InnerProduct) {
				t.Fatal("completeness invariant failed")
			}
			for _, v := range []uint64{0, 1, 2, 23} {
				x := field(v)
				aEval, bEval := Evaluate(trace.Pay, x), Evaluate(trace.Pby, x)
				var left, right, vanish fr.Element
				left.Mul(&aEval, &bEval).Mul(&left, ptrField(uint64(n))).Sub(&left, &trace.Mu)
				vanish.Exp(x, big.NewInt(int64(n))).Sub(&vanish, ptrField(1))
				right = Evaluate(trace.Q, x)
				right.Mul(&right, &vanish)
				tail := Evaluate(trace.T, x)
				tail.Mul(&tail, &x)
				right.Add(&right, &tail)
				if !left.Equal(&right) {
					t.Fatal("complete polynomial identity failed")
				}
			}
			if e = VerifyComplete(p, s, *proof); e != nil {
				t.Fatal(e)
			}
			wire, e := proof.MarshalBinary()
			if e != nil {
				t.Fatal(e)
			}
			if len(wire) != 196 {
				t.Fatal("wrong complete proof size")
			}
			decoded, e := UnmarshalCompleteProof(wire)
			if e != nil {
				t.Fatal(e)
			}
			sb, e := s.MarshalBinary()
			if e != nil {
				t.Fatal(e)
			}
			ds, e := UnmarshalStatement(sb)
			if e != nil {
				t.Fatal(e)
			}
			if e = VerifyComplete(p, ds, decoded); e != nil {
				t.Fatal(e)
			}
			bad := *proof
			bad.VMu = addG1(bad.VMu, p.Base().srs.Pk.G1[0])
			if !errors.Is(VerifyComplete(p, s, bad), ErrRejected) {
				t.Fatal("modified mu accepted")
			}
		}
	}
}

func TestCompletenessMismatchAndWireErrors(t *testing.T) {
	p := completeTestParams(t, 4)
	r := rand.New(rand.NewSource(3))
	a, b := RandomMatrix(r, 4, 4), RandomMatrix(r, 4, 4)
	c, e := Multiply(a, b)
	if e != nil {
		t.Fatal(e)
	}
	c.Data[0].Add(&c.Data[0], ptrField(1))
	s, e := CommitMatrices(p.Base(), a, b, c)
	if e != nil {
		t.Fatal(e)
	}
	proof, trace, e := ProveComplete(p, s, a, b, c)
	if !errors.Is(e, ErrInnerProductMismatch) || proof != nil || trace.ConstantRemainder.IsZero() {
		t.Fatal("mu mismatch discarded")
	}
	if _, e = UnmarshalCompleteProof(make([]byte, 196)); e == nil {
		t.Fatal("missing format marker accepted")
	}
	if _, e = UnmarshalCompleteBatchProof([]byte("ZKB1")); e == nil {
		t.Fatal("short batch accepted")
	}
}

func TestCompletenessWeightedBatchHonestNonzeroInputs(t *testing.T) {
	p := completeTestParams(t, 4)
	r := rand.New(rand.NewSource(43))
	ss := make([]Statement, 3)
	proofs := make([]CompleteProof, 3)
	for i := range ss {
		a, b := RandomMatrix(r, 4, 4), RandomMatrix(r, 4, 4)
		c, e := Multiply(a, b)
		if e != nil {
			t.Fatal(e)
		}
		ss[i], e = CommitMatrices(p.Base(), a, b, c)
		if e != nil {
			t.Fatal(e)
		}
		proof, _, e := ProveComplete(p, ss[i], a, b, c)
		if e != nil {
			t.Fatal(e)
		}
		proofs[i] = *proof
	}
	for _, q := range []int{1, 2, 3} {
		for _, rho := range []fr.Element{field(0), field(1), field(7)} {
			bp, e := AggregateComplete(p, proofs[:q], rho)
			if e != nil {
				t.Fatal(e)
			}
			if e = VerifyCompleteBatch(p, ss[:q], *bp, rho); e != nil {
				t.Fatalf("q=%d: %v", q, e)
			}
			wire, e := bp.MarshalBinary()
			if e != nil {
				t.Fatal(e)
			}
			if len(wire) != 104+96*q {
				t.Fatal("wrong batch size")
			}
			dp, e := UnmarshalCompleteBatchProof(wire)
			if e != nil {
				t.Fatal(e)
			}
			if e = VerifyCompleteBatch(p, ss[:q], dp, rho); e != nil {
				t.Fatal(e)
			}
			dp.VMu = addG1(dp.VMu, p.Base().srs.Pk.G1[0])
			if !errors.Is(VerifyCompleteBatch(p, ss[:q], dp, rho), ErrRejected) {
				t.Fatal("batch mu mutation accepted")
			}
		}
	}
	bp, e := AggregateComplete(p, proofs, field(7))
	if e != nil {
		t.Fatal(e)
	}
	if e = VerifyCompleteBatch(p, ss[:2], *bp, field(7)); e == nil {
		t.Fatal("claim count mismatch accepted")
	}
	wire, e := bp.MarshalBinary()
	if e != nil {
		t.Fatal(e)
	}
	if _, e = UnmarshalCompleteBatchProof(wire[:len(wire)-1]); e == nil {
		t.Fatal("truncated batch accepted")
	}
	for i := 40; i < 104; i++ {
		wire[i] = 255
	}
	if _, e = UnmarshalCompleteBatchProof(wire); e == nil {
		t.Fatal("invalid G2 accepted")
	}
}

func TestCompletenessProductionSetupAndDomainSeparation(t *testing.T) {
	p, e := SetupComplete(4, 16)
	if e != nil {
		t.Fatal(e)
	}
	if p.G2Points() != 5 {
		t.Fatal("missing G2 powers")
	}
	if _, e = SetupComplete(3, 9); e == nil {
		t.Fatal("non-root domain accepted")
	}
	if _, e = SetupComplete(4, 8); e == nil {
		t.Fatal("limit ignored")
	}
	base := testParams(t, 4, Roots)
	cp, e := completeParamsFromSRS(4, base.srs, big.NewInt(17))
	if e != nil {
		t.Fatal(e)
	}
	s := Statement{}
	old, newY := Challenge(base, s), ChallengeComplete(cp, s)
	if old.Equal(&newY) {
		t.Fatal("variant shares transcript")
	}
}
