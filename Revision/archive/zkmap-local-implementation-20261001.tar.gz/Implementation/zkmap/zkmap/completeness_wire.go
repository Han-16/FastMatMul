package zkmap

import (
	"bytes"
	"encoding/binary"
	"fmt"
	"github.com/consensys/gnark-crypto/ecc/bn254"
)

func decodeG2(b []byte) (bn254.G2Affine, error) {
	var p bn254.G2Affine
	if len(b) != 64 {
		return p, fmt.Errorf("expected 64-byte G2")
	}
	n, e := p.SetBytes(b)
	if e != nil || n != 64 {
		return p, fmt.Errorf("invalid compressed G2")
	}
	canonical := p.Bytes()
	if !bytes.Equal(b, canonical[:]) {
		return p, fmt.Errorf("noncanonical G2")
	}
	return p, nil
}

func (p CompleteProof) MarshalBinary() ([]byte, error) {
	if e := validateCompleteProof(p); e != nil {
		return nil, e
	}
	out := append([]byte("ZKC1"), encodePoints(p.VAy, p.VMu, p.VQ, p.VT)...)
	by := p.VBy.Bytes()
	return append(out, by[:]...), nil
}
func UnmarshalCompleteProof(b []byte) (CompleteProof, error) {
	if len(b) != 196 || string(b[:4]) != "ZKC1" {
		return CompleteProof{}, fmt.Errorf("expected ZKC1 completeness proof (196 bytes)")
	}
	g1, e := decodePoints(b[4:132], 4)
	if e != nil {
		return CompleteProof{}, e
	}
	g2, e := decodeG2(b[132:])
	if e != nil {
		return CompleteProof{}, e
	}
	return CompleteProof{VAy: g1[0], VMu: g1[1], VQ: g1[2], VT: g1[3], VBy: g2}, nil
}

func (p CompleteBatchProof) MarshalBinary() ([]byte, error) {
	if len(p.Products) < 1 || len(p.Products) > 10000 {
		return nil, fmt.Errorf("invalid completeness batch count")
	}
	if e := validPoints(p.VMu, p.VQ, p.VT); e != nil {
		return nil, e
	}
	out := make([]byte, 8)
	copy(out, "ZKB1")
	binary.BigEndian.PutUint32(out[4:], uint32(len(p.Products)))
	for _, product := range p.Products {
		if e := validPoints(product.VAy); e != nil {
			return nil, e
		}
		if e := validG2(product.VBy); e != nil {
			return nil, e
		}
		out = append(out, encodePoints(product.VAy)...)
		by := product.VBy.Bytes()
		out = append(out, by[:]...)
	}
	return append(out, encodePoints(p.VMu, p.VQ, p.VT)...), nil
}
func UnmarshalCompleteBatchProof(b []byte) (CompleteBatchProof, error) {
	if len(b) < 8 || string(b[:4]) != "ZKB1" {
		return CompleteBatchProof{}, fmt.Errorf("expected ZKB1 completeness batch")
	}
	q := int(binary.BigEndian.Uint32(b[4:8]))
	if q < 1 || q > 10000 || len(b) != 104+96*q {
		return CompleteBatchProof{}, fmt.Errorf("invalid completeness batch length/count")
	}
	out := CompleteBatchProof{Products: make([]CompleteProduct, q)}
	offset := 8
	for i := range out.Products {
		g1, e := decodePoints(b[offset:offset+32], 1)
		if e != nil {
			return CompleteBatchProof{}, e
		}
		g2, e := decodeG2(b[offset+32 : offset+96])
		if e != nil {
			return CompleteBatchProof{}, e
		}
		out.Products[i] = CompleteProduct{g1[0], g2}
		offset += 96
	}
	tail, e := decodePoints(b[offset:], 3)
	if e != nil {
		return CompleteBatchProof{}, e
	}
	out.VMu = tail[0]
	out.VQ = tail[1]
	out.VT = tail[2]
	return out, nil
}
