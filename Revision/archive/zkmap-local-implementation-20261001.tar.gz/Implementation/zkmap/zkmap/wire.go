package zkmap

import (
	"bytes"
	"fmt"
	"github.com/consensys/gnark-crypto/ecc/bn254"
	"github.com/consensys/gnark-crypto/ecc/bn254/fr"
)

// These fixed-size encodings are implementation choices, not the paper's
// claimed 320-byte encoding. Payload and statement sizes are counted separately.
func encodePoints(points ...bn254.G1Affine) []byte {
	out := make([]byte, 0, 32*len(points))
	for _, p := range points {
		b := p.Bytes()
		out = append(out, b[:]...)
	}
	return out
}
func decodePoints(b []byte, count int) ([]bn254.G1Affine, error) {
	if len(b) != count*32 {
		return nil, fmt.Errorf("expected %d bytes, got %d", count*32, len(b))
	}
	out := make([]bn254.G1Affine, count)
	for i := range out {
		chunk := b[i*32 : (i+1)*32]
		n, err := out[i].SetBytes(chunk)
		if err != nil || n != 32 {
			return nil, fmt.Errorf("invalid compressed G1 at index %d", i)
		}
		canonical := out[i].Bytes()
		if !bytes.Equal(chunk, canonical[:]) {
			return nil, fmt.Errorf("noncanonical G1")
		}
	}
	return out, nil
}
func (s Statement) MarshalBinary() ([]byte, error) {
	if err := validPoints(s.VA, s.VB, s.VC); err != nil {
		return nil, err
	}
	return encodePoints(s.VA, s.VB, s.VC), nil
}
func UnmarshalStatement(b []byte) (Statement, error) {
	p, e := decodePoints(b, 3)
	if e != nil {
		return Statement{}, e
	}
	return Statement{p[0], p[1], p[2]}, nil
}
func (p Proof) MarshalBinary() ([]byte, error) {
	if err := validPoints(p.VAy, p.VBy, p.VMu, p.VW); err != nil {
		return nil, err
	}
	return encodePoints(p.VAy, p.VBy, p.VMu, p.VW), nil
}
func UnmarshalProof(b []byte) (Proof, error) {
	p, e := decodePoints(b, 4)
	if e != nil {
		return Proof{}, e
	}
	return Proof{p[0], p[1], p[2], p[3]}, nil
}
func (p BatchProof) MarshalBinary() ([]byte, error) {
	if err := validPoints(p.VA, p.VB, p.D, p.VW); err != nil {
		return nil, err
	}
	return encodePoints(p.VA, p.VB, p.D, p.VW), nil
}
func UnmarshalBatchProof(b []byte) (BatchProof, error) {
	p, e := decodePoints(b, 4)
	if e != nil {
		return BatchProof{}, e
	}
	return BatchProof{p[0], p[1], p[2], p[3]}, nil
}

// Section4Scalar diagnostic requires 64 extra bytes absent from Appendix E.
func MarshalScalarContext(a, b fr.Element) []byte {
	av, bv := a.Bytes(), b.Bytes()
	out := append([]byte(nil), av[:]...)
	return append(out, bv[:]...)
}
func UnmarshalScalarContext(b []byte) (fr.Element, fr.Element, error) {
	var a, c fr.Element
	if len(b) != 64 {
		return a, c, fmt.Errorf("scalar context requires 64 bytes")
	}
	if err := a.SetBytesCanonical(b[:32]); err != nil {
		return a, c, err
	}
	err := c.SetBytesCanonical(b[32:])
	return a, c, err
}
