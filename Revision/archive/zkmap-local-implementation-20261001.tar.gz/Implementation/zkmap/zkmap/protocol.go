// Package zkmap preserves a literal paper reproduction and exposes an explicitly
// separate local completeness variant in completeness.go.
package zkmap

import (
	"crypto/rand"
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"errors"
	"fmt"
	"math/big"

	"github.com/consensys/gnark-crypto/ecc/bn254"
	"github.com/consensys/gnark-crypto/ecc/bn254/fr"
	"github.com/consensys/gnark-crypto/ecc/bn254/kzg"
)

type Params struct {
	n        int
	encoding Encoding
	srs      *kzg.SRS
	digest   [32]byte
	srsBytes int64
}

func (p *Params) N() int                { return p.n }
func (p *Params) Encoding() Encoding    { return p.encoding }
func (p *Params) SRSDigest() string     { return hex.EncodeToString(p.digest[:]) }
func (p *Params) SRSInfo() (int, int64) { return len(p.srs.Pk.G1), p.srsBytes }

// Setup implements Eq. (10), with crypto/rand and no trapdoor in Params.
// An element limit must be explicitly raised for large server workloads.
func Setup(n, maxElements int, encoding Encoding) (*Params, error) {
	if n < 2 || n > 1<<13 || n*n > maxElements {
		return nil, fmt.Errorf("n must be 2..8192 and n^2 <= max-matrix-elements")
	}
	if err := encoding.Validate(); err != nil {
		return nil, err
	}
	if encoding == Roots && !powerOfTwo(n) {
		return nil, fmt.Errorf("roots-of-unity requires power-of-two n")
	}
	var alpha *big.Int
	for alpha == nil || alpha.Sign() == 0 {
		v, err := rand.Int(rand.Reader, fr.Modulus())
		if err != nil {
			return nil, err
		}
		alpha = v
	}
	srs, err := kzg.NewSRS(uint64(n*n), alpha)
	if err != nil {
		return nil, err
	}
	// Hash the complete canonical public SRS once, outside online proving.
	h := sha256.New()
	size, err := srs.WriteTo(h)
	if err != nil {
		return nil, err
	}
	p := &Params{n: n, encoding: encoding, srs: srs, srsBytes: size}
	copy(p.digest[:], h.Sum(nil))
	return p, nil
}

type Statement struct{ VA, VB, VC bn254.G1Affine }
type Proof struct{ VAy, VBy, VMu, VW bn254.G1Affine }

func (p *Params) checkMatrix(m Matrix) error {
	if err := m.Validate(); err != nil {
		return err
	}
	if m.Rows != p.n || m.Cols != p.n {
		return fmt.Errorf("Algorithm 2 requires %dx%d matrices", p.n, p.n)
	}
	return nil
}

func CommitMatrices(p *Params, a, b, c Matrix) (Statement, error) {
	for _, m := range []Matrix{a, b, c} {
		if err := p.checkMatrix(m); err != nil {
			return Statement{}, err
		}
	}
	va, err := kzg.Commit(a.Data, p.srs.Pk)
	if err != nil {
		return Statement{}, err
	}
	vb, err := kzg.Commit(b.Data, p.srs.Pk)
	if err != nil {
		return Statement{}, err
	}
	vc, err := kzg.Commit(c.Data, p.srs.Pk)
	return Statement{va, vb, vc}, err
}

// Challenge is Eq. (12). SHA-256, domain label, dimension encoding, SRS digest,
// encoding name and compressed point encoding are explicit implementation choices.
func Challenge(p *Params, s Statement) fr.Element {
	h := sha256.New()
	h.Write([]byte("zkmap-paper-reproduction/v1/BN254/"))
	var n [8]byte
	binary.BigEndian.PutUint64(n[:], uint64(p.n))
	h.Write(n[:])
	h.Write(p.digest[:])
	h.Write([]byte(p.encoding))
	h.Write([]byte{0})
	for _, point := range []bn254.G1Affine{s.VA, s.VB, s.VC} {
		b := point.Bytes()
		h.Write(b[:])
	}
	var y fr.Element
	y.SetBytes(h.Sum(nil))
	return y
}

type Computation struct {
	Y, Mu, InnerProduct, AEval, BEval, Remainder fr.Element
	Pay, Pby, Witness                            []fr.Element
}

type WitnessRemainderError struct{ Remainder fr.Element }

func (e *WitnessRemainderError) Error() string {
	return "Algorithm 2 line 17: numerator is not divisible by X-y; remainder=" + e.Remainder.String()
}

// Prove follows Algorithm 2 lines 7..18, returning no proof when W is rational.
// It assumes the caller supplies the same matrices committed by Statement, as
// the paper does; it adds neither a linking proof nor a secret evaluation at s.
func Prove(p *Params, s Statement, a, b, c Matrix) (*Proof, *Computation, error) {
	for _, m := range []Matrix{a, b, c} {
		if err := p.checkMatrix(m); err != nil {
			return nil, nil, err
		}
	}
	trace := &Computation{Y: Challenge(p, s)}
	projection, err := Project(a, b, c, trace.Y)
	if err != nil {
		return nil, trace, err
	}
	trace.Mu = projection.Mu
	trace.InnerProduct = projection.InnerProduct
	trace.Pay, err = EncodeProjection(projection.A, p.encoding)
	if err != nil {
		return nil, trace, err
	}
	trace.Pby, err = EncodeProjection(projection.B, p.encoding)
	if err != nil {
		return nil, trace, err
	}
	proof := &Proof{}
	proof.VAy, err = kzg.Commit(trace.Pay, p.srs.Pk)
	if err != nil {
		return nil, trace, err
	}
	proof.VBy, err = kzg.Commit(trace.Pby, p.srs.Pk)
	if err != nil {
		return nil, trace, err
	}
	proof.VMu = scaleG1(p.srs.Pk.G1[0], trace.Mu)
	trace.AEval = Evaluate(trace.Pay, trace.Y)
	trace.BEval = Evaluate(trace.Pby, trace.Y)
	numerator := PolynomialProduct(trace.Pay, trace.Pby)
	for i := range numerator {
		numerator[i].Neg(&numerator[i])
	}
	numerator[0].Add(&numerator[0], &trace.Mu)
	trace.Witness, trace.Remainder = DivideByLinear(numerator, trace.Y)
	if !trace.Remainder.IsZero() {
		return nil, trace, &WitnessRemainderError{trace.Remainder}
	}
	proof.VW, err = kzg.Commit(trace.Witness, p.srs.Pk)
	if err != nil {
		return nil, trace, err
	}
	return proof, trace, nil
}

var ErrRejected = errors.New("published pairing equation rejected the proof")
var ErrUndefinedGroupProduct = errors.New("Appendix F line 26: product of two G1 points is not defined by the paper")

func scaleG1(point bn254.G1Affine, scalar fr.Element) bn254.G1Affine {
	var out bn254.G1Affine
	out.ScalarMultiplication(&point, scalar.BigInt(new(big.Int)))
	return out
}
func scaleG2(point bn254.G2Affine, scalar fr.Element) bn254.G2Affine {
	var out bn254.G2Affine
	out.ScalarMultiplication(&point, scalar.BigInt(new(big.Int)))
	return out
}
func addG1(a, b bn254.G1Affine) bn254.G1Affine { var out bn254.G1Affine; out.Add(&a, &b); return out }
func subG1(a, b bn254.G1Affine) bn254.G1Affine {
	var neg bn254.G1Affine
	neg.Neg(&b)
	return addG1(a, neg)
}

func validPoints(points ...bn254.G1Affine) error {
	for _, p := range points {
		if !p.IsOnCurve() || !p.IsInSubGroup() {
			return fmt.Errorf("invalid G1 point")
		}
	}
	return nil
}

func checkPairing(p *Params, vw, rhs bn254.G1Affine, y fr.Element) error {
	d2 := scaleG2(p.srs.Vk.G2[0], y)
	d2.Neg(&d2)
	d2.Add(&d2, &p.srs.Vk.G2[1])
	neg := rhs
	neg.Neg(&rhs)
	ok, err := bn254.PairingCheck([]bn254.G1Affine{vw, neg}, []bn254.G2Affine{d2, p.srs.Vk.G2[0]})
	if err != nil {
		return err
	}
	if !ok {
		return ErrRejected
	}
	return nil
}

// VerifyAppendixE implements exactly line 24, combining its three RHS pairings
// by bilinearity: Vmu - Vay - Vby. It never reads witness matrices.
func VerifyAppendixE(p *Params, s Statement, proof Proof) error {
	if err := validPoints(s.VA, s.VB, s.VC, proof.VAy, proof.VBy, proof.VMu, proof.VW); err != nil {
		return err
	}
	rhs := subG1(subG1(proof.VMu, proof.VAy), proof.VBy)
	return checkPairing(p, proof.VW, rhs, Challenge(p, s))
}

// VerifySection4Scalar implements the FIRST displayed equation on page 16.
// aEval/bEval are additional diagnostic inputs: the paper's seven-point proof
// contains no scalars and gives no way for this verifier to recover them.
// No openings or binding checks are added, and the extra input is disclosed.
func VerifySection4Scalar(p *Params, s Statement, proof Proof, aEval, bEval fr.Element) error {
	if err := validPoints(s.VA, s.VB, s.VC, proof.VAy, proof.VBy, proof.VMu, proof.VW); err != nil {
		return err
	}
	var product fr.Element
	product.Mul(&aEval, &bEval)
	rhs := subG1(proof.VMu, scaleG1(p.srs.Pk.G1[0], product))
	return checkPairing(p, proof.VW, rhs, Challenge(p, s))
}

type BatchProof struct{ VA, VB, D, VW bn254.G1Affine }
type BatchProduct string

const (
	LiteralBatch BatchProduct = "literal"
	ScalarBatch  BatchProduct = "scalar-evaluation"
)

// Aggregate follows Algorithm 3 lines 24..28. LiteralBatch fails explicitly at
// the undefined G1 product. ScalarBatch is an optional equation diagnostic,
// using the explicit scalar reading from Section 4.4, not a repaired zkMaP.
func Aggregate(p *Params, ss []Statement, proofs []Proof, traces []*Computation, rho fr.Element, mode BatchProduct) (BatchProof, error) {
	if len(ss) == 0 || len(ss) != len(proofs) || len(ss) != len(traces) {
		return BatchProof{}, fmt.Errorf("invalid batch lengths")
	}
	if mode == LiteralBatch {
		return BatchProof{}, ErrUndefinedGroupProduct
	}
	if mode != ScalarBatch {
		return BatchProof{}, fmt.Errorf("unknown batch product reading")
	}
	var out BatchProof
	var weight fr.Element
	weight.SetOne()
	for i := range ss {
		if traces[i] == nil {
			return BatchProof{}, fmt.Errorf("missing scalar diagnostic inputs")
		}
		var product fr.Element
		product.Mul(&traces[i].AEval, &traces[i].BEval)
		d := subG1(proofs[i].VMu, scaleG1(p.srs.Pk.G1[0], product))
		out.VA = addG1(out.VA, scaleG1(ss[i].VA, weight))
		out.VB = addG1(out.VB, scaleG1(ss[i].VB, weight))
		out.D = addG1(out.D, scaleG1(d, weight))
		out.VW = addG1(out.VW, scaleG1(proofs[i].VW, weight))
		weight.Mul(&weight, &rho)
	}
	return out, nil
}

// SampleRho is the uniformly random field element at Algorithm 3 line 24,
// including zero. No transcript hashing or new challenge restrictions added.
func SampleRho() (fr.Element, error) {
	v, err := rand.Int(rand.Reader, fr.Modulus())
	if err != nil {
		return fr.Element{}, err
	}
	var rho fr.Element
	rho.SetBigInt(v)
	return rho, nil
}

// VerifyBatch evaluates lines 31..32 WITHOUT replacing weighted y by a
// different multi-opening equation. ss and rho are explicitly supplied context
// missing from the returned four-point tuple in Algorithm 3 line 28.
func VerifyBatch(p *Params, ss []Statement, proof BatchProof, rho fr.Element) error {
	if len(ss) == 0 {
		return fmt.Errorf("empty batch")
	}
	if err := validPoints(proof.VA, proof.VB, proof.D, proof.VW); err != nil {
		return err
	}
	var z, weight fr.Element
	weight.SetOne()
	for _, s := range ss {
		if err := validPoints(s.VA, s.VB, s.VC); err != nil {
			return err
		}
		y := Challenge(p, s)
		y.Mul(&y, &weight)
		z.Add(&z, &y)
		weight.Mul(&weight, &rho)
	}
	return checkPairing(p, proof.VW, proof.D, z)
}
