package zkmap

import (
	"crypto/sha256"
	"errors"
	"math/big"
	"math/rand"
	"testing"

	"github.com/consensys/gnark-crypto/ecc/bn254"
	"github.com/consensys/gnark-crypto/ecc/bn254/fr"
	"github.com/consensys/gnark-crypto/ecc/bn254/kzg"
)

func field(v uint64) fr.Element { var e fr.Element; e.SetUint64(v); return e }
func matrix(rows, cols int, values ...uint64) Matrix {
	m := Matrix{rows, cols, make([]fr.Element, rows*cols)}
	for i, v := range values {
		m.Data[i] = field(v)
	}
	return m
}
func testParams(t *testing.T, n int, mode Encoding) *Params {
	t.Helper()
	srs, err := kzg.NewSRS(uint64(n*n), big.NewInt(17))
	if err != nil {
		t.Fatal(err)
	}
	h := sha256.New()
	size, err := srs.WriteTo(h)
	if err != nil {
		t.Fatal(err)
	}
	p := &Params{n: n, encoding: mode, srs: srs, srsBytes: size}
	copy(p.digest[:], h.Sum(nil))
	return p
}

func TestMatrixProductAndProjection(t *testing.T) {
	a := matrix(2, 3, 2, 3, 5, 7, 11, 13)
	b := matrix(3, 2, 17, 19, 23, 29, 31, 37)
	c, err := Multiply(a, b)
	if err != nil {
		t.Fatal(err)
	}
	for i, v := range []uint64{258, 310, 775, 933} {
		want := field(v)
		if !c.Data[i].Equal(&want) {
			t.Fatalf("entry %d incorrect", i)
		}
	}
	p, err := Project(a, b, c, field(7))
	if err != nil {
		t.Fatal(err)
	}
	if !p.Mu.Equal(&p.InnerProduct) {
		t.Fatal("matrix projection identity failed")
	}
	eval := Evaluate(c.Data, field(7))
	if !p.Mu.Equal(&eval) {
		t.Fatal("output row-major evaluation inconsistent")
	}
	// Full-field square random values, not only small integer/zero examples.
	r := rand.New(rand.NewSource(42))
	for _, n := range []int{2, 4, 8} {
		a := RandomMatrix(r, n, n)
		b := RandomMatrix(r, n, n)
		c, e := Multiply(a, b)
		if e != nil {
			t.Fatal(e)
		}
		p, e := Project(a, b, c, field(19))
		if e != nil || !p.Mu.Equal(&p.InnerProduct) {
			t.Fatalf("n=%d: projection identity", n)
		}
	}
}

func TestInterpolationRoundTrip(t *testing.T) {
	values := []fr.Element{field(2), field(3), field(5), field(7), field(11), field(13), field(17), field(19)}
	for _, mode := range []Encoding{Roots, Integers} {
		p, e := EncodeProjection(values, mode)
		if e != nil {
			t.Fatal(e)
		}
		omega, e := fr.Generator(uint64(len(values)))
		if e != nil {
			t.Fatal(e)
		}
		point := field(1)
		for i, want := range values {
			if mode == Integers {
				point = field(uint64(i))
			}
			got := Evaluate(p, point)
			if !got.Equal(&want) {
				t.Fatalf("%s node %d mismatch", mode, i)
			}
			if mode == Roots {
				point.Mul(&point, &omega)
			}
		}
	}
	p, e := EncodeProjection(values, Coefficients)
	if e != nil {
		t.Fatal(e)
	}
	for i := range p {
		if !p[i].Equal(&values[i]) {
			t.Fatal("coefficient encoding changed")
		}
	}
	if _, e := EncodeProjection(values[:3], Roots); e == nil {
		t.Fatal("non-power-of-two roots accepted")
	}
}

func TestPolynomialConvolutionAndExactDivision(t *testing.T) {
	for _, size := range []int{1, 2, 3, 8, 31} {
		a, b := make([]fr.Element, size), make([]fr.Element, size+1)
		for i := range a {
			a[i] = field(uint64(i + 3))
		}
		for i := range b {
			b[i] = field(uint64(i + 7))
		}
		p := PolynomialProduct(a, b)
		expected := make([]fr.Element, len(a)+len(b)-1)
		for i := range a {
			for j := range b {
				var v fr.Element
				v.Mul(&a[i], &b[j])
				expected[i+j].Add(&expected[i+j], &v)
			}
		}
		for i := range p {
			if !p[i].Equal(&expected[i]) {
				t.Fatalf("convolution size %d entry %d", size, i)
			}
		}
		y := field(23)
		q, r := DivideByLinear(p, y)
		want := Evaluate(p, y)
		if !r.Equal(&want) {
			t.Fatal("remainder != P(y)")
		}
		for _, x := range []uint64{0, 1, 2, 29} {
			point := field(x)
			lhs := Evaluate(p, point)
			rhs := Evaluate(q, point)
			point.Sub(&point, &y)
			rhs.Mul(&rhs, &point).Add(&rhs, &r)
			if !lhs.Equal(&rhs) {
				t.Fatal("synthetic division reconstruction failed")
			}
		}
	}
}

func TestHonestGeneralInputsReturnNoPolynomialWitness(t *testing.T) {
	random := rand.New(rand.NewSource(1))
	a := RandomMatrix(random, 4, 4)
	b := RandomMatrix(random, 4, 4)
	c, e := Multiply(a, b)
	if e != nil {
		t.Fatal(e)
	}
	for _, mode := range []Encoding{Roots, Integers, Coefficients} {
		t.Run(string(mode), func(t *testing.T) {
			p := testParams(t, 4, mode)
			s, e := CommitMatrices(p, a, b, c)
			if e != nil {
				t.Fatal(e)
			}
			proof, trace, e := Prove(p, s, a, b, c)
			var rem *WitnessRemainderError
			if !errors.As(e, &rem) || proof != nil {
				t.Fatalf("expected no exact witness, got %v", e)
			}
			if trace.Remainder.IsZero() {
				t.Fatal("missing remainder")
			}
			if !trace.Mu.Equal(&trace.InnerProduct) {
				t.Fatal("failure caused by incorrect matrix projection")
			}
			var product, expected fr.Element
			product.Mul(&trace.AEval, &trace.BEval)
			expected.Sub(&trace.Mu, &product)
			if !expected.Equal(&trace.Remainder) {
				t.Fatal("reported remainder incorrect")
			}
		})
	}
}

func TestNonzeroExceptionalHonestProofAndDistinctVerifiers(t *testing.T) {
	p := testParams(t, 2, Coefficients)
	for _, pair := range [][2]uint64{{2, 2}, {3, 5}} {
		a, b := matrix(2, 2, pair[0], 0, 0, 0), matrix(2, 2, pair[1], 0, 0, 0)
		c, e := Multiply(a, b)
		if e != nil {
			t.Fatal(e)
		}
		s, e := CommitMatrices(p, a, b, c)
		if e != nil {
			t.Fatal(e)
		}
		proof, trace, e := Prove(p, s, a, b, c)
		if e != nil {
			t.Fatal(e)
		}
		if e = VerifySection4Scalar(p, s, *proof, trace.AEval, trace.BEval); e != nil {
			t.Fatal(e)
		}
		e = VerifyAppendixE(p, s, *proof)
		if pair == [2]uint64{2, 2} {
			if e != nil {
				t.Fatal(e)
			}
		} else if !errors.Is(e, ErrRejected) {
			t.Fatalf("literal Appendix must subtract, not multiply: %v", e)
		}
		altered := *proof
		altered.VMu = addG1(altered.VMu, p.srs.Pk.G1[0])
		if !errors.Is(VerifySection4Scalar(p, s, altered, trace.AEval, trace.BEval), ErrRejected) {
			t.Fatal("mutated proof accepted")
		}
		encoded, e := proof.MarshalBinary()
		if e != nil {
			t.Fatal(e)
		}
		decoded, e := UnmarshalProof(encoded)
		if e != nil {
			t.Fatal(e)
		}
		if e = VerifySection4Scalar(p, s, decoded, trace.AEval, trace.BEval); e != nil {
			t.Fatal(e)
		}
	}
}

func TestZeroFixtureAndWireFormat(t *testing.T) {
	p := testParams(t, 4, Roots)
	m := matrix(4, 4)
	s, e := CommitMatrices(p, m, m, m)
	if e != nil {
		t.Fatal(e)
	}
	proof, _, e := Prove(p, s, m, m, m)
	if e != nil {
		t.Fatal(e)
	}
	if e = VerifyAppendixE(p, s, *proof); e != nil {
		t.Fatal(e)
	}
	sb, e := s.MarshalBinary()
	if e != nil {
		t.Fatal(e)
	}
	pb, e := proof.MarshalBinary()
	if e != nil {
		t.Fatal(e)
	}
	if len(sb) != 96 || len(pb) != 128 {
		t.Fatal("actual compressed size wrong")
	}
	ds, e := UnmarshalStatement(sb)
	if e != nil {
		t.Fatal(e)
	}
	dp, e := UnmarshalProof(pb)
	if e != nil {
		t.Fatal(e)
	}
	if e = VerifyAppendixE(p, ds, dp); e != nil {
		t.Fatal(e)
	}
	if _, e = UnmarshalProof(pb[:127]); e == nil {
		t.Fatal("truncated proof accepted")
	}
	if _, e = UnmarshalStatement(append(sb, 0)); e == nil {
		t.Fatal("trailing bytes accepted")
	}
	malformed := append([]byte(nil), pb...)
	for i := 0; i < 32; i++ {
		malformed[i] = 255
	}
	if _, e = UnmarshalProof(malformed); e == nil {
		t.Fatal("invalid curve encoding accepted")
	}
	context := MarshalScalarContext(field(3), field(5))
	av, bv, e := UnmarshalScalarContext(context)
	if e != nil || av.String() != "3" || bv.String() != "5" {
		t.Fatal("scalar context round trip")
	}
}

func TestBatchLiteralBoundaryAndZeroScalarDiagnostic(t *testing.T) {
	p := testParams(t, 2, Roots)
	m := matrix(2, 2)
	s, e := CommitMatrices(p, m, m, m)
	if e != nil {
		t.Fatal(e)
	}
	proof, trace, e := Prove(p, s, m, m, m)
	if e != nil {
		t.Fatal(e)
	}
	ss := []Statement{s, s, s}
	proofs := []Proof{*proof, *proof, *proof}
	traces := []*Computation{trace, trace, trace}
	if _, e = Aggregate(p, ss, proofs, traces, field(2), LiteralBatch); !errors.Is(e, ErrUndefinedGroupProduct) {
		t.Fatalf("literal product was silently invented: %v", e)
	}
	bp, e := Aggregate(p, ss, proofs, traces, field(2), ScalarBatch)
	if e != nil {
		t.Fatal(e)
	}
	if e = VerifyBatch(p, ss, bp, field(2)); e != nil {
		t.Fatal(e)
	}
	b, e := bp.MarshalBinary()
	if e != nil {
		t.Fatal(e)
	}
	decoded, e := UnmarshalBatchProof(b)
	if e != nil {
		t.Fatal(e)
	}
	if e = VerifyBatch(p, ss, decoded, field(2)); e != nil {
		t.Fatal(e)
	}
}

func TestBatchWeightedChallengeEquationIsNotRepaired(t *testing.T) {
	// Algebraic fixture only: two proofs satisfy the page-16 scalar equation.
	// Test that implementation keeps Algorithm 3's weighted challenge, including
	// its failure on this fixture, rather than introducing a corrected equation.
	p := testParams(t, 2, Roots)
	ss := make([]Statement, 2)
	proofs := make([]Proof, 2)
	traces := make([]*Computation, 2)
	for i := range ss {
		ss[i] = Statement{VA: scaleG1(p.srs.Pk.G1[0], field(uint64(i+2))), VB: scaleG1(p.srs.Pk.G1[0], field(3)), VC: scaleG1(p.srs.Pk.G1[0], field(5))}
		y := Challenge(p, ss[i])
		w := field(uint64(i + 7))
		d1 := subG1(p.srs.Pk.G1[1], scaleG1(p.srs.Pk.G1[0], y))
		proofs[i] = Proof{VMu: scaleG1(d1, w), VW: scaleG1(p.srs.Pk.G1[0], w)}
		traces[i] = &Computation{Y: y}
		if e := VerifySection4Scalar(p, ss[i], proofs[i], fr.Element{}, fr.Element{}); e != nil {
			t.Fatal(e)
		}
	}
	bp, e := Aggregate(p, ss, proofs, traces, field(2), ScalarBatch)
	if e != nil {
		t.Fatal(e)
	}
	if !errors.Is(VerifyBatch(p, ss, bp, field(2)), ErrRejected) {
		t.Fatal("published weighted challenge unexpectedly changed")
	}
}

func TestCompressionEquation15(t *testing.T) {
	m := matrix(2, 2, 2, 3, 5, 7)
	out, e := CompressColumns(m, field(2), 3)
	if e != nil {
		t.Fatal(e)
	}
	for i, v := range []uint64{7, 10, 12, 17, 22, 31} {
		want := field(v)
		if !out.Data[i].Equal(&want) {
			t.Fatalf("compression coefficient %d", i)
		}
	}
}

func TestSetupLimitsAndRealRandomSetup(t *testing.T) {
	if _, e := Setup(128, 64, Roots); e == nil {
		t.Fatal("element limit ignored")
	}
	if _, e := Setup(3, 9, Roots); e == nil {
		t.Fatal("roots limit ignored")
	}
	p, e := Setup(2, 4, Roots)
	if e != nil {
		t.Fatal(e)
	}
	points, size := p.SRSInfo()
	if points != 4 || size <= 0 || p.SRSDigest() == "" {
		t.Fatal("SRS metadata missing")
	}
	var invalid bn254.G1Affine
	invalid.X.SetOne()
	if validPoints(invalid) == nil {
		t.Fatal("off-curve point accepted")
	}
}
