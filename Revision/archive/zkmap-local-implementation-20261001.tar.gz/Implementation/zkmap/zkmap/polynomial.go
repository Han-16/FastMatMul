package zkmap

import (
	"fmt"
	"github.com/consensys/gnark-crypto/ecc/bn254/fr"
	"github.com/consensys/gnark-crypto/ecc/bn254/fr/fft"
)

type Encoding string

const (
	Roots        Encoding = "roots-of-unity"
	Integers     Encoding = "integer-nodes"
	Coefficients Encoding = "coefficients"
)

func (e Encoding) Validate() error {
	switch e {
	case Roots, Integers, Coefficients:
		return nil
	}
	return fmt.Errorf("unknown projection encoding %q", e)
}
func powerOfTwo(n int) bool { return n > 0 && n&(n-1) == 0 }

// EncodeProjection supplies the convention omitted by Algorithm 2 line 12.
// Roots/Integers interpolate values; Coefficients is a distinct Section 4.2
// coefficient-encoding reading, not an interpolation algorithm.
func EncodeProjection(values []fr.Element, mode Encoding) ([]fr.Element, error) {
	if len(values) == 0 {
		return nil, fmt.Errorf("empty projection")
	}
	if err := mode.Validate(); err != nil {
		return nil, err
	}
	p := append([]fr.Element(nil), values...)
	switch mode {
	case Roots:
		if !powerOfTwo(len(p)) {
			return nil, fmt.Errorf("roots-of-unity requires power-of-two projection length")
		}
		d := fft.NewDomain(uint64(len(p)))
		d.FFTInverse(p, fft.DIF)
		fft.BitReverse(p)
	case Integers:
		// Newton divided differences at 0,...,n-1, then conversion to coefficients.
		for order := 1; order < len(p); order++ {
			var divisor fr.Element
			divisor.SetUint64(uint64(order))
			divisor.Inverse(&divisor)
			for i := len(p) - 1; i >= order; i-- {
				p[i].Sub(&p[i], &p[i-1])
				p[i].Mul(&p[i], &divisor)
			}
		}
		out := []fr.Element{p[len(p)-1]}
		for i := len(p) - 2; i >= 0; i-- {
			var node fr.Element
			node.SetUint64(uint64(i))
			next := make([]fr.Element, len(out)+1)
			for j := range out {
				var v fr.Element
				v.Mul(&out[j], &node).Neg(&v)
				next[j].Add(&next[j], &v)
				next[j+1].Add(&next[j+1], &out[j])
			}
			next[0].Add(&next[0], &p[i])
			out = next
		}
		p = out
	}
	return p, nil
}

func Evaluate(p []fr.Element, x fr.Element) fr.Element {
	var out fr.Element
	for i := len(p) - 1; i >= 0; i-- {
		out.Mul(&out, &x).Add(&out, &p[i])
	}
	return out
}

// PolynomialProduct uses NTT convolution with exact padding (no truncation).
func PolynomialProduct(a, b []fr.Element) []fr.Element {
	if len(a) == 0 || len(b) == 0 {
		return nil
	}
	length := len(a) + len(b) - 1
	size := 1
	for size < length {
		size <<= 1
	}
	av, bv := make([]fr.Element, size), make([]fr.Element, size)
	copy(av, a)
	copy(bv, b)
	d := fft.NewDomain(uint64(size))
	d.FFT(av, fft.DIF)
	d.FFT(bv, fft.DIF)
	for i := range av {
		av[i].Mul(&av[i], &bv[i])
	}
	d.FFTInverse(av, fft.DIT)
	return av[:length]
}

// DivideByLinear returns Q,R with P(X)=(X-y)Q(X)+R. R is never discarded.
func DivideByLinear(p []fr.Element, y fr.Element) ([]fr.Element, fr.Element) {
	if len(p) == 0 {
		return []fr.Element{{}}, fr.Element{}
	}
	if len(p) == 1 {
		return []fr.Element{{}}, p[0]
	}
	q := make([]fr.Element, len(p)-1)
	q[len(q)-1] = p[len(p)-1]
	for i := len(q) - 2; i >= 0; i-- {
		q[i].Mul(&q[i+1], &y).Add(&q[i], &p[i+1])
	}
	var remainder fr.Element
	remainder.Mul(&q[0], &y).Add(&remainder, &p[0])
	return q, remainder
}

// CompressColumns implements only Eq. (15), for the specified omega and ell.
// It does not invent the missing outer group-polynomial evaluation protocol.
func CompressColumns(m Matrix, omega fr.Element, ell int) (Matrix, error) {
	if err := m.Validate(); err != nil {
		return Matrix{}, err
	}
	if ell < 1 || ell > 1<<15 {
		return Matrix{}, fmt.Errorf("invalid compression row count")
	}
	out := Matrix{ell, m.Cols, make([]fr.Element, ell*m.Cols)}
	var point fr.Element
	point.SetOne()
	for i := 0; i < ell; i++ {
		for j := 0; j < m.Cols; j++ {
			var v fr.Element
			for k := m.Rows - 1; k >= 0; k-- {
				v.Mul(&v, &point).Add(&v, &m.Data[k*m.Cols+j])
			}
			out.Data[i*m.Cols+j] = v
		}
		point.Mul(&point, &omega)
	}
	return out, nil
}
