package zkmap

import (
	"crypto/rand"
	"crypto/sha256"
	"errors"
	"fmt"
	"math/big"

	"github.com/consensys/gnark-crypto/ecc"
	"github.com/consensys/gnark-crypto/ecc/bn254"
	"github.com/consensys/gnark-crypto/ecc/bn254/fr"
	"github.com/consensys/gnark-crypto/ecc/bn254/kzg"
)

const CompletenessVariant = "completeness-roots-v1"

// CompleteParams extends the uncompressed matrix SRS with G2 powers 0..n.
// This is a local completeness variant, NOT the published zkMaP protocol.
type CompleteParams struct {
	base *Params
	g2   []bn254.G2Affine
}

func (p *CompleteParams) Base() *Params { return p.base }
func (p *CompleteParams) G2Points() int { return len(p.g2) }

func SetupComplete(n, maxElements int) (*CompleteParams, error) {
	if n < 2 || n > 1<<13 || n*n > maxElements || !powerOfTwo(n) {
		return nil, fmt.Errorf("completeness-roots requires power-of-two n=2..8192 within element limit")
	}
	var alpha *big.Int
	for alpha == nil || alpha.Sign() == 0 {
		v, e := rand.Int(rand.Reader, fr.Modulus())
		if e != nil {
			return nil, e
		}
		alpha = v
	}
	srs, e := kzg.NewSRS(uint64(n*n), alpha)
	if e != nil {
		return nil, e
	}
	return completeParamsFromSRS(n, srs, alpha)
}

// The trapdoor is used only during setup. Neither returned parameter struct
// retains it; the prover/verifier use public group points exclusively.
func completeParamsFromSRS(n int, srs *kzg.SRS, alpha *big.Int) (*CompleteParams, error) {
	powers := make([]fr.Element, n+1)
	powers[0].SetOne()
	var a fr.Element
	a.SetBigInt(alpha)
	for i := 1; i <= n; i++ {
		powers[i].Mul(&powers[i-1], &a)
	}
	g2 := bn254.BatchScalarMultiplicationG2(&srs.Vk.G2[0], powers)
	h := sha256.New()
	h.Write([]byte(CompletenessVariant))
	size, e := srs.WriteTo(h)
	if e != nil {
		return nil, e
	}
	// G2[0],G2[1] are already present in srs.WriteTo. Append only extra powers.
	for _, point := range g2[2:] {
		b := point.Bytes()
		h.Write(b[:])
		size += int64(len(b))
	}
	base := &Params{n: n, encoding: Roots, srs: srs, srsBytes: size}
	copy(base.digest[:], h.Sum(nil))
	return &CompleteParams{base: base, g2: g2}, nil
}

func ChallengeComplete(p *CompleteParams, s Statement) fr.Element {
	y := Challenge(p.base, s)
	b := y.Bytes()
	h := sha256.New()
	h.Write([]byte(CompletenessVariant + "/challenge/"))
	h.Write(b[:])
	var out fr.Element
	out.SetBytes(h.Sum(nil))
	return out
}

type CompleteProof struct {
	VAy, VMu, VQ, VT bn254.G1Affine
	VBy              bn254.G2Affine
}
type CompleteComputation struct {
	Y, Mu, InnerProduct, ConstantRemainder fr.Element
	Pay, Pby, Q, T                         []fr.Element
}

var ErrInnerProductMismatch = errors.New("completeness variant: constant remainder does not match the projected inner product")

// DivideByVanishing returns Q,R for P=Q(X)(X^n-1)+R, deg R<n.
func DivideByVanishing(poly []fr.Element, n int) ([]fr.Element, []fr.Element, error) {
	if n < 1 {
		return nil, nil, fmt.Errorf("invalid vanishing degree")
	}
	remainder := make([]fr.Element, max(n, len(poly)))
	copy(remainder, poly)
	q := make([]fr.Element, max(1, len(poly)-n))
	for i := len(poly) - 1; i >= n; i-- {
		q[i-n] = remainder[i]
		remainder[i-n].Add(&remainder[i-n], &remainder[i])
		remainder[i].SetZero()
	}
	return q, remainder[:n], nil
}

// ProveComplete replaces the erroneous one-point product with a roots sum:
// n Pay(X) Pby(X) - mu = Q(X)(X^n-1) + X T(X).
// For interpolation at n-th roots, the constant remainder is zero whenever
// mu=sum ay[k]by[k]. This guarantees honest algebraic completeness.
func ProveComplete(p *CompleteParams, s Statement, a, b, c Matrix) (*CompleteProof, *CompleteComputation, error) {
	for _, m := range []Matrix{a, b, c} {
		if e := p.base.checkMatrix(m); e != nil {
			return nil, nil, e
		}
	}
	trace := &CompleteComputation{Y: ChallengeComplete(p, s)}
	projection, e := Project(a, b, c, trace.Y)
	if e != nil {
		return nil, trace, e
	}
	trace.Mu = projection.Mu
	trace.InnerProduct = projection.InnerProduct
	trace.Pay, e = EncodeProjection(projection.A, Roots)
	if e != nil {
		return nil, trace, e
	}
	trace.Pby, e = EncodeProjection(projection.B, Roots)
	if e != nil {
		return nil, trace, e
	}
	numerator := PolynomialProduct(trace.Pay, trace.Pby)
	var n fr.Element
	n.SetUint64(uint64(p.base.n))
	for i := range numerator {
		numerator[i].Mul(&numerator[i], &n)
	}
	numerator[0].Sub(&numerator[0], &trace.Mu)
	var remainder []fr.Element
	trace.Q, remainder, e = DivideByVanishing(numerator, p.base.n)
	if e != nil {
		return nil, trace, e
	}
	trace.ConstantRemainder = remainder[0]
	if !trace.ConstantRemainder.IsZero() {
		return nil, trace, ErrInnerProductMismatch
	}
	trace.T = append([]fr.Element(nil), remainder[1:]...)
	proof := &CompleteProof{}
	proof.VAy, e = kzg.Commit(trace.Pay, p.base.srs.Pk)
	if e != nil {
		return nil, trace, e
	}
	if _, e = proof.VBy.MultiExp(p.g2[:len(trace.Pby)], trace.Pby, ecc.MultiExpConfig{}); e != nil {
		return nil, trace, e
	}
	proof.VMu = scaleG1(p.base.srs.Pk.G1[0], trace.Mu)
	proof.VQ, e = kzg.Commit(trace.Q, p.base.srs.Pk)
	if e != nil {
		return nil, trace, e
	}
	proof.VT, e = kzg.Commit(trace.T, p.base.srs.Pk)
	if e != nil {
		return nil, trace, e
	}
	return proof, trace, nil
}

func validG2(p bn254.G2Affine) error {
	if !p.IsOnCurve() || !p.IsInSubGroup() {
		return fmt.Errorf("invalid G2 point")
	}
	return nil
}

func validateCompleteProof(proof CompleteProof) error {
	if e := validPoints(proof.VAy, proof.VMu, proof.VQ, proof.VT); e != nil {
		return e
	}
	return validG2(proof.VBy)
}

// VerifyComplete checks the new inner-product polynomial identity with four
// pairing terms. It does not add links to VA/VB/VC, degree proofs or hiding.
// Statement points are format checked only; this is not a soundness repair.
func VerifyComplete(p *CompleteParams, s Statement, proof CompleteProof) error {
	if e := validPoints(s.VA, s.VB, s.VC); e != nil {
		return e
	}
	if e := validateCompleteProof(proof); e != nil {
		return e
	}
	var n fr.Element
	n.SetUint64(uint64(p.base.n))
	left := scaleG1(proof.VAy, n)
	mu, q, t := proof.VMu, proof.VQ, proof.VT
	mu.Neg(&mu)
	q.Neg(&q)
	t.Neg(&t)
	var vanishing bn254.G2Affine
	vanishing.Sub(&p.g2[p.base.n], &p.g2[0])
	ok, e := bn254.PairingCheck([]bn254.G1Affine{left, mu, q, t}, []bn254.G2Affine{proof.VBy, p.g2[0], vanishing, p.g2[1]})
	if e != nil {
		return e
	}
	if !ok {
		return ErrRejected
	}
	return nil
}

type CompleteProduct struct {
	VAy bn254.G1Affine
	VBy bn254.G2Affine
}
type CompleteBatchProof struct {
	Products    []CompleteProduct
	VMu, VQ, VT bn254.G1Affine
}

// AggregateComplete preserves each product pairing, and only folds terms that
// share their G2 argument. It does not use the incomplete weighted-y formula.
// Thus this dependent batch change has q+3 pairing terms and O(q) proof bytes.
func AggregateComplete(p *CompleteParams, proofs []CompleteProof, rho fr.Element) (*CompleteBatchProof, error) {
	if len(proofs) == 0 {
		return nil, fmt.Errorf("empty completeness batch")
	}
	out := &CompleteBatchProof{Products: make([]CompleteProduct, len(proofs))}
	weight := fr.One()
	for i, proof := range proofs {
		if e := validateCompleteProof(proof); e != nil {
			return nil, e
		}
		out.Products[i] = CompleteProduct{proof.VAy, proof.VBy}
		out.VMu = addG1(out.VMu, scaleG1(proof.VMu, weight))
		out.VQ = addG1(out.VQ, scaleG1(proof.VQ, weight))
		out.VT = addG1(out.VT, scaleG1(proof.VT, weight))
		weight.Mul(&weight, &rho)
	}
	return out, nil
}

func VerifyCompleteBatch(p *CompleteParams, ss []Statement, proof CompleteBatchProof, rho fr.Element) error {
	if len(ss) == 0 || len(ss) != len(proof.Products) {
		return fmt.Errorf("completeness batch statement/product count mismatch")
	}
	if e := validPoints(proof.VMu, proof.VQ, proof.VT); e != nil {
		return e
	}
	g1 := make([]bn254.G1Affine, 0, len(ss)+3)
	g2 := make([]bn254.G2Affine, 0, len(ss)+3)
	weight := fr.One()
	var n fr.Element
	n.SetUint64(uint64(p.base.n))
	for i, product := range proof.Products {
		if e := validPoints(ss[i].VA, ss[i].VB, ss[i].VC, product.VAy); e != nil {
			return e
		}
		if e := validG2(product.VBy); e != nil {
			return e
		}
		var scaled fr.Element
		scaled.Mul(&weight, &n)
		g1 = append(g1, scaleG1(product.VAy, scaled))
		g2 = append(g2, product.VBy)
		weight.Mul(&weight, &rho)
	}
	mu, q, t := proof.VMu, proof.VQ, proof.VT
	mu.Neg(&mu)
	q.Neg(&q)
	t.Neg(&t)
	var vanishing bn254.G2Affine
	vanishing.Sub(&p.g2[p.base.n], &p.g2[0])
	g1 = append(g1, mu, q, t)
	g2 = append(g2, p.g2[0], vanishing, p.g2[1])
	ok, e := bn254.PairingCheck(g1, g2)
	if e != nil {
		return e
	}
	if !ok {
		return ErrRejected
	}
	return nil
}
