package zkmap

import (
	"fmt"
	"math/rand"
	"runtime"
	"sync"

	"github.com/consensys/gnark-crypto/ecc/bn254/fr"
)

// Matrix holds row-major coefficients, as in Section 4.1 / Algorithm 2 line 2.
type Matrix struct {
	Rows, Cols int
	Data       []fr.Element
}

func (m Matrix) Validate() error {
	if m.Rows < 1 || m.Cols < 1 || m.Rows > 1<<15 || m.Cols > 1<<15 || len(m.Data) != m.Rows*m.Cols {
		return fmt.Errorf("invalid matrix shape or coefficient count")
	}
	return nil
}

// RandomMatrix uses the same rejection-sampling and RNG order as cmd/zkmatrix.
// The seed controls input data only; Setup always uses crypto/rand.
func RandomMatrix(r *rand.Rand, rows, cols int) Matrix {
	m := Matrix{rows, cols, make([]fr.Element, rows*cols)}
	var raw [32]byte
	for i := range m.Data {
		for {
			for k := 0; k < 4; k++ {
				v := r.Uint64()
				for j := 0; j < 8; j++ {
					raw[k*8+j] = byte(v >> (56 - 8*j))
				}
			}
			if m.Data[i].SetBytesCanonical(raw[:]) == nil {
				break
			}
		}
	}
	return m
}

// Multiply computes actual matrix multiplication, independently of encodings.
// This O(n^3) workload is timed separately from proof generation.
func Multiply(a, b Matrix) (Matrix, error) {
	if err := a.Validate(); err != nil {
		return Matrix{}, err
	}
	if err := b.Validate(); err != nil {
		return Matrix{}, err
	}
	if a.Cols != b.Rows {
		return Matrix{}, fmt.Errorf("incompatible matrix dimensions")
	}
	c := Matrix{a.Rows, b.Cols, make([]fr.Element, a.Rows*b.Cols)}
	workers := min(runtime.GOMAXPROCS(0), a.Rows)
	var wg sync.WaitGroup
	for w := 0; w < workers; w++ {
		wg.Add(1)
		go func(w int) {
			defer wg.Done()
			for i := w; i < a.Rows; i += workers {
				for k := 0; k < a.Cols; k++ {
					av := a.Data[i*a.Cols+k]
					for j := 0; j < b.Cols; j++ {
						var term fr.Element
						term.Mul(&av, &b.Data[k*b.Cols+j])
						c.Data[i*b.Cols+j].Add(&c.Data[i*b.Cols+j], &term)
					}
				}
			}
		}(w)
	}
	wg.Wait()
	return c, nil
}

type Projection struct {
	A, B             []fr.Element
	Mu, InnerProduct fr.Element
}

// Project is Eq. (13) and Algorithm 2 lines 11,15. For rectangular matrices,
// the stride in yL is the output column count, so yL^T C yR = PC(y).
func Project(a, b, c Matrix, y fr.Element) (Projection, error) {
	for _, m := range []Matrix{a, b, c} {
		if err := m.Validate(); err != nil {
			return Projection{}, err
		}
	}
	if a.Cols != b.Rows || c.Rows != a.Rows || c.Cols != b.Cols {
		return Projection{}, fmt.Errorf("incompatible projection dimensions")
	}
	p := Projection{A: make([]fr.Element, a.Cols), B: make([]fr.Element, b.Rows)}
	var step, power fr.Element
	step.SetOne()
	for j := 0; j < c.Cols; j++ {
		step.Mul(&step, &y)
	}
	yl := make([]fr.Element, a.Rows)
	yr := make([]fr.Element, b.Cols)
	power.SetOne()
	for i := range yl {
		yl[i] = power
		power.Mul(&power, &step)
	}
	power.SetOne()
	for j := range yr {
		yr[j] = power
		power.Mul(&power, &y)
	}
	for i := 0; i < a.Rows; i++ {
		for k := 0; k < a.Cols; k++ {
			var term fr.Element
			term.Mul(&yl[i], &a.Data[i*a.Cols+k])
			p.A[k].Add(&p.A[k], &term)
		}
	}
	for k := 0; k < b.Rows; k++ {
		for j := 0; j < b.Cols; j++ {
			var term fr.Element
			term.Mul(&b.Data[k*b.Cols+j], &yr[j])
			p.B[k].Add(&p.B[k], &term)
		}
	}
	for i := 0; i < c.Rows; i++ {
		for j := 0; j < c.Cols; j++ {
			var term fr.Element
			term.Mul(&yl[i], &c.Data[i*c.Cols+j])
			term.Mul(&term, &yr[j])
			p.Mu.Add(&p.Mu, &term)
		}
	}
	for k := range p.A {
		var term fr.Element
		term.Mul(&p.A[k], &p.B[k])
		p.InnerProduct.Add(&p.InnerProduct, &term)
	}
	return p, nil
}
