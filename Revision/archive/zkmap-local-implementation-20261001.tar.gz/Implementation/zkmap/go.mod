module example.com/lamp-zkmap

go 1.25.6

require github.com/consensys/gnark-crypto v0.19.3-0.20260210233638-4abc1c162a65

require (
	github.com/bits-and-blooms/bitset v1.24.4 // indirect
	golang.org/x/sys v0.41.0 // indirect
)
