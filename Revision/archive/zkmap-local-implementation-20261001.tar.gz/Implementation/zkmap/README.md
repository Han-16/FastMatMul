# zkMaP 논문 식 재현 구현

2026-10-01: 사용자의 요청으로 **completeness만 수정한 별도 경로** `-variant completeness-roots-v1`를 추가했다. 일반 정상 입력의 작은 로컬 테스트에서 생성·검증·직렬화 재검증이 성공한다. 수식과 비용 변화는 [COMPLETENESS_REPAIR.md](COMPLETENESS_REPAIR.md), 결과는 `test-results/20261001/`에 기록한다. 아래의 실패 설명은 기본 `-variant paper` 원본 재현 경로에 대한 것이다. 성능 실험은 실행하지 않았다.

이 디렉터리는 `Revision/zkMaP.pdf`의 Section 4와 Appendix E/F를 재현하는 독립 Go 모듈이다. LAMP·zkMatrix와 동일한 BN254 및 gnark-crypto 버전을 사용한다. 기본 `paper` 경로는 논문의 명시된 식을 수정하지 않는다. 별도 completeness 수정판은 정상 입력의 대수적 수락을 구현하며 soundness·zero knowledge 보완은 포함하지 않는다.

**기본 원본 경로에서는 일반 정상 입력에서 정확한 witness 다항식 생성이 실패한다.** 세 가지 projection 인코딩 해석을 테스트하며, 나머지를 버리거나 setup trapdoor로 유리식을 평가하지 않는다. 기존 실패 테스트는 이 동작을 확인한다. 수정판의 성공 테스트와 구분한다. 서버 성능 비교는 아직 실행하지 않았다.

## 파일 및 원문 대응

| 원문 | 구현 | 동작 |
| --- | --- | --- |
| Section 4.1, Eq. (10),(11), Appendix E 2–4행 | `zkmap/protocol.go`: Setup, CommitMatrices | row-major coefficient KZG commitment, n² G1 SRS |
| Eq. (12), Appendix E 7행 | Challenge | parameters·SRS 식별자·ABC commitment에서 challenge |
| Eq. (13), Appendix E 11,15행 | `zkmap/matrix.go`: Project | yL, yR, ay, by, mu |
| Appendix E 12행 | `zkmap/polynomial.go`: EncodeProjection | 명시하지 않은 보간 노드를 설정으로 선택 |
| Eq. (14), Appendix E 17–18행 | Prove, DivideByLinear | 정확한 polynomial quotient만 commitment; 나머지 있으면 실패 |
| Appendix E 24행 | VerifyAppendixE | RHS=Vmu−Vay−Vby를 실제 pairing으로 검사 |
| Section 4.4 첫 검증식, p.16 | VerifySection4Scalar | RHS=Vmu−Pay(y)Pby(y)G1; 별도 scalar 입력이 필요한 진단 경로 |
| Appendix F 24–28행 | SampleRho, Aggregate | literal G1 곱 미정의 오류; 별도 scalar 해석은 진단 옵션 |
| Appendix F 31–32행 | VerifyBatch | z=Σrho^(i−1)yi, 원문의 pairing 식 유지 |
| Section 4.3 Eq. (15) | CompressColumns | 지정 omega와 ell에 대한 column projection만 구현 |
| 실제 bytes 계수 | `zkmap/wire.go` | statement 96B, single proof 128B, batch tuple 128B; parameters/SRS 제외 |
| 실행·측정 | `cmd/zkmap/` | JSONL, 실패 상태, 소스/바이너리/SRS fingerprint |

## 명세 해석 선택

- `roots-of-unity` (기본): projection 벡터를 순서대로 n차 단위근에서의 값으로 보고 inverse FFT로 보간한다. Appendix E/F에는 노드가 지정되어 있지 않으므로 이것은 구현 선택이다.
- `integer-nodes`: 0,...,n−1에서의 값으로 보간한다. 기존 `crypto/zkmap_audit` 진단과 같은 노드 해석이다. O(n²) 보간이므로 큰 서버 측정은 기본 roots 설정을 사용한다.
- `coefficients`: projection을 다항식 계수로 사용한다. Section 4.2의 “encode”에 대한 별도 해석이며 Appendix의 “interpolate”를 그대로 구현한 것으로 부르지 않는다.
- Hash는 SHA-256의 field reduction이다. `pp`에는 domain label/곡선명, big-endian n, 전체 public SRS의 canonical serialization SHA-256, 인코딩 이름을 넣는다. ABC 점은 compressed canonical bytes다. 논문에는 hash 함수와 정확한 serialization이 없다.
- Appendix E의 7개 점은 public statement 3개와 proof payload 4개로 분리하여 계수한다. 전체는 compressed 224B이며 논문이 주장하는 320B를 상수로 출력하지 않는다. Section 4 scalar 진단에는 추가 입력 64B를 별도 계수한다.
- 단일 입력의 RNG 및 full-field rejection sampling, 반복 seed `seed+(run−1)*7919`는 보관된 `cmd/zkmatrix/main.go`와 맞춘다. 각 배치 claim도 독립 행렬곱이다. setup randomness는 cryptographic이다. zero fixture는 실험용 랜덤 입력이 아니다.

## 그대로 실행할 수 없는 부분

1. **정확한 witness:** 필요한 조건은 `mu=Pay(y)Pby(y)`다. 실제 행렬곱의 projection이 보장하는 것은 `mu=Σ ay[k]by[k]`이며, 위 세 가지 인코딩이 두 식을 일반적으로 같게 만들지는 않는다. 정확한 나머지를 결과에 남긴다.
2. **본문 scalar 검증:** 7-point proof에는 Pay(y),Pby(y)가 없고 원문에 이 값을 복구하는 방법도 없다. `section4-scalar`는 전달된 두 값을 사용한 식의 진단이며, binding check나 evaluation proof를 추가하지 않는다.
3. **배치 G1 곱:** Algorithm 3 26행의 `Vay·Vby`는 같은 G1 안의 연산으로 정의되어 있지 않다. 기본 `literal`은 이 행에서 명시적으로 실패한다. 선택적 `scalar-evaluation`은 본문의 명시적 field product 해석을 적용한 진단이다. 일반 zkMaP batch 재현 성공으로 취급하지 않는다. weighted challenge 식도 수정하지 않는다.
4. **배치 context:** 28행의 네 점만으로 verifier는 개별 yi와 rho를 재구성할 수 없다. 기존 statement 목록 96q B와 rho 32B를 제공한 context로 기록한다. scalar aggregation 진단의 64q B 계산 입력은 verifier context와 분리한다. 새로운 Fiat–Shamir 규칙을 넣지 않는다.
5. **압축 최종 commitment:** p.15의 `G(s)=Σ Vi s^i`는 group coefficients에 비밀 s를 적용하는 방법이 SRS n개로 명시되어 있지 않다. `F(s,s)`로 직접 다항식을 펼치면 최대 차수가 ell+n−2가 되어 명시된 n-point SRS와도 달라진다. Eq. (15)만 제공하고 outer commitment/전체 압축 프로토콜은 구현하지 않는다. 기본 Alg. 2의 uncompressed 경로를 사용한다.
6. **GPT-2:** square·batch와 달리 이질적인 rectangular 곱과 연결 관계가 필요하다. 현재 코드는 square Alg. 2/F만 실행한다. profile에는 보관 소스에서 확인한 36개 곱의 shape만 기록한다. 이를 전체 GPT-2 구현으로 주장하지 않는다.

## 빌드 및 로컬 테스트

Go 1.25.6 이상이 필요하다. 모듈 디렉터리에서 실행한다.

```sh
cd Implementation/zkmap
go test ./...
python3 -m unittest discover -s scripts -p 'test_*.py'
go build -o bin/zkmap ./cmd/zkmap
./bin/zkmap -K 2 -threads 2 -output random-k2.jsonl
```

마지막 명령은 일반 정상 입력의 witness 실패를 JSONL로 남기며 종료 코드 2를 반환한다. 성공 경로의 작은 fixture 확인:

```sh
./bin/zkmap -K 2 -threads 2 -input zero -output zero-fixture.jsonl
./bin/zkmap -K 2 -threads 2 -input zero -batch 3 -batch-product scalar-evaluation -output batch-scalar-fixture.jsonl
```

zero fixture의 성공을 일반 입력의 성공 결과 또는 성능 비교에 사용하지 않는다. 실제 nonzero exceptional 입력의 성공 및 본문/Appendix 검증 결과 차이는 Go 테스트에 포함되어 있다.

종료 코드: 0=모든 시도 수락 및 payload 재검증, 1=인수/파일/실행 오류, 2=식 재현의 증명 생성·검증 실패 또는 미정의 연산. 기존 output 파일은 덮어쓰지 않는다. 실패한 실행에는 proof bytes와 verify 시간을 성공 값으로 채우지 않는다.

## Section 7 서버 실험 연결

```sh
python3 scripts/run_section7.py --profile both --plan
```

정방행렬 128~8192 7개, k=128 batch q=1~10, 각 10회·32 threads의 17개 명령을 출력한다. LAMP rho=1/2,t=309는 비교 조건 metadata이며 zkMaP에는 적용되지 않는다. setup과 실제 AB 계산은 online prove에서 제외하고, matrix commitment는 포함한다. 원시 records는 환경/코드 hash/실패 상태를 포함한다. 이 runner는 zkMaP만 실행하므로 기존 LAMP·zkMatrix runner는 같은 서버에서 별도로 실행한다.

실제 실행은 서버에서 다음과 같이 명시적으로 선택한다.

```sh
python3 scripts/run_section7.py --profile both --execute --output /path/to/new-zkmap-results
```

작은 정상 입력 preflight가 실패하면 full-size 측정을 실행하지 않는다. 이는 구현 식의 동작 확인이다. 실패의 큰 크기 재현이 목적이면 `--allow-failed-attempts`를 추가할 수 있다. 해당 결과는 실패 시도이며 유효 proof 성능으로 집계하지 않는다. 현재 로컬 작업에서는 서버에 접속하거나 대규모 측정을 실행하지 않았다.

세부 실행 기록은 `test-results/20260930/`, 전체 작업 계획은 저장소 루트의 `ZKMAP_IMPLEMENTATION_PLAN.md`를 참고한다.
