package main

import "github.com/consensys/gnark-crypto/ecc/bn254/fr"

func makeZero(n int) []fr.Element { return make([]fr.Element, n) }
