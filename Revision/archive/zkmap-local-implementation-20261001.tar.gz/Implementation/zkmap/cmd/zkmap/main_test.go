package main

import (
	"bytes"
	"encoding/json"
	"os"
	"path/filepath"
	"testing"
)

func TestCLIPlanDoesNotSetup(t *testing.T) {
	var out, errOut bytes.Buffer
	code := run([]string{"-K", "13", "-max-matrix-elements", "67108864", "-plan"}, &out, &errOut)
	if code != 0 {
		t.Fatal(errOut.String())
	}
	var r map[string]any
	if e := json.Unmarshal(out.Bytes(), &r); e != nil {
		t.Fatal(e)
	}
	if r["n"] != float64(8192) || r["allocated"] != false || r["setup_executed"] != false {
		t.Fatal(r)
	}
}
func TestCLIHonestFailureIsRecordedWithoutProofBytes(t *testing.T) {
	var out, errOut bytes.Buffer
	code := run([]string{"-K", "1", "-repetitions", "2", "-threads", "1"}, &out, &errOut)
	if code != 2 {
		t.Fatalf("exit=%d: %s", code, errOut.String())
	}
	dec := json.NewDecoder(&out)
	for i := 1; i <= 2; i++ {
		var r record
		if e := dec.Decode(&r); e != nil {
			t.Fatal(e)
		}
		if r.Status != "witness_remainder_nonzero" || r.ProofGenerated || r.Verification != nil || r.ProofBytes != nil || r.Run != i || r.Seed != 1+int64(i-1)*7919 {
			t.Fatalf("misleading failure record: %+v", r)
		}
		if !r.Claims[0].ProjectionIdentity || r.Source["source_tree_sha256"] == nil {
			t.Fatal("missing identity or provenance")
		}
	}
}
func TestCLIZeroSuccessAndNoOverwrite(t *testing.T) {
	path := filepath.Join(t.TempDir(), "zero.jsonl")
	var out, errOut bytes.Buffer
	args := []string{"-K", "1", "-input", "zero", "-threads", "1", "-output", path}
	if code := run(args, &out, &errOut); code != 0 {
		t.Fatal(errOut.String())
	}
	before, e := os.ReadFile(path)
	if e != nil {
		t.Fatal(e)
	}
	var r record
	if e = json.Unmarshal(before, &r); e != nil {
		t.Fatal(e)
	}
	if r.Verification == nil || !*r.Verification || r.PayloadReverified == nil || !*r.PayloadReverified || *r.ProofBytes != 128 || r.StatementBytes != 96 {
		t.Fatal("zero smoke did not complete")
	}
	if code := run(args, &out, &errOut); code != 1 {
		t.Fatal("existing output overwritten")
	}
	after, e := os.ReadFile(path)
	if e != nil || !bytes.Equal(before, after) {
		t.Fatal("existing output changed")
	}
}
func TestCLIBatchLiteralAndDiagnostic(t *testing.T) {
	for _, mode := range []string{"literal", "scalar-evaluation"} {
		var out, errOut bytes.Buffer
		code := run([]string{"-K", "1", "-input", "zero", "-batch", "3", "-batch-product", mode, "-threads", "1"}, &out, &errOut)
		var r record
		if e := json.Unmarshal(out.Bytes(), &r); e != nil {
			t.Fatal(e)
		}
		if mode == "literal" {
			if code != 2 || r.Status != "batch_aggregation_failed" || r.ProofGenerated {
				t.Fatal("undefined operation hidden")
			}
		} else if code != 0 || r.Verification == nil || !*r.Verification || r.StatementBytes != 288 || r.ContextBytes != 32 || r.AggregateInputs != 192 {
			t.Fatalf("scalar diagnostic failure: %+v", r)
		}
	}
}
