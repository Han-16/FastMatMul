package main

import (
	"bytes"
	"encoding/json"
	"example.com/lamp-zkmap/zkmap"
	"testing"
)

func TestCLICompletenessNormalInputsSingleAndBatch(t *testing.T) {
	for _, batch := range []string{"0", "3"} {
		var out, errOut bytes.Buffer
		code := run([]string{"-variant", zkmap.CompletenessVariant, "-K", "2", "-threads", "2", "-batch", batch}, &out, &errOut)
		if code != 0 {
			t.Fatalf("exit %d: %s", code, errOut.String())
		}
		var r record
		if e := json.Unmarshal(out.Bytes(), &r); e != nil {
			t.Fatal(e)
		}
		if r.Variant != zkmap.CompletenessVariant || r.Fidelity != "local_completeness_variant_not_published_zkmap" || r.Verification == nil || !*r.Verification || r.PayloadReverified == nil || !*r.PayloadReverified || r.Input != "random" {
			t.Fatal("modified variant not identified or did not verify")
		}
		for _, claim := range r.Claims {
			if claim.Remainder != "0" || !claim.ProjectionIdentity {
				t.Fatal("completeness invariant missing")
			}
		}
	}
}
func TestCLICompletenessRejectsOtherEncodingOverrides(t *testing.T) {
	var out, errOut bytes.Buffer
	if code := run([]string{"-variant", zkmap.CompletenessVariant, "-projection-encoding", "integer-nodes"}, &out, &errOut); code != 1 {
		t.Fatal("incompatible basis silently accepted")
	}
}
