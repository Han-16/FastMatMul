package main

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"math/rand"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"runtime/debug"
	"strconv"
	"strings"
	"time"

	"example.com/lamp-zkmap/zkmap"
)

type claimRecord struct {
	Status             string `json:"status"`
	Error              string `json:"error,omitempty"`
	Challenge          string `json:"challenge,omitempty"`
	Remainder          string `json:"witness_remainder,omitempty"`
	ProjectionIdentity bool   `json:"projection_identity_holds"`
	ProofGenerated     bool   `json:"proof_generated"`
	Verification       *bool  `json:"verification_succeeded"`
}
type record struct {
	Schema            int                `json:"schema_version"`
	Scheme            string             `json:"scheme"`
	Fidelity          string             `json:"protocol_fidelity"`
	Variant           string             `json:"variant"`
	Status            string             `json:"status"`
	Error             string             `json:"error,omitempty"`
	Workload          string             `json:"workload"`
	N                 int                `json:"n"`
	BatchQ            int                `json:"batch_q"`
	Run               int                `json:"run"`
	Seed              int64              `json:"effective_seed"`
	Threads           int                `json:"threads"`
	Encoding          string             `json:"projection_encoding"`
	Verifier          string             `json:"verifier"`
	BatchProduct      string             `json:"batch_product_reading"`
	Input             string             `json:"input_profile"`
	ProofGenerated    bool               `json:"proof_generated"`
	Verification      *bool              `json:"verification_succeeded"`
	PayloadReverified *bool              `json:"decoded_payload_verification_succeeded"`
	ProofBytes        *int               `json:"proof_bytes"`
	StatementBytes    int                `json:"statement_bytes"`
	ContextBytes      int                `json:"additional_verifier_context_bytes"`
	AggregateInputs   int                `json:"aggregate_scalar_input_bytes"`
	Timings           map[string]float64 `json:"timings_seconds"`
	Claims            []claimRecord      `json:"claims"`
	Host              map[string]any     `json:"host"`
	Source            map[string]any     `json:"source"`
	SRS               map[string]any     `json:"srs"`
	LAMPReference     map[string]any     `json:"lamp_reference_parameters"`
	Accounting        string             `json:"timing_accounting_profile"`
}
type options struct {
	k, batch, reps, threads, maxElements                     int
	seed                                                     int64
	encoding, verifier, batchProduct, input, output, variant string
	plan                                                     bool
}

func main() { os.Exit(run(os.Args[1:], os.Stdout, os.Stderr)) }
func run(args []string, out, errOut io.Writer) int {
	o := options{}
	fs := flag.NewFlagSet("zkmap", flag.ContinueOnError)
	fs.SetOutput(errOut)
	fs.IntVar(&o.k, "K", 2, "log2 square dimension (1..13)")
	fs.IntVar(&o.batch, "batch", 0, "0 = single proof; positive = Algorithm 3 independent claims")
	fs.IntVar(&o.reps, "repetitions", 1, "number of attempts (failed attempts retained)")
	fs.IntVar(&o.threads, "threads", runtime.NumCPU(), "GOMAXPROCS")
	fs.IntVar(&o.maxElements, "max-matrix-elements", 1<<20, "per matrix element limit; raise explicitly on server")
	fs.Int64Var(&o.seed, "seed", 1, "input-data seed, same RNG order as zkMatrix")
	fs.StringVar(&o.variant, "variant", "paper", "paper or completeness-roots-v1 (local modified protocol)")
	fs.StringVar(&o.encoding, "projection-encoding", string(zkmap.Roots), "roots-of-unity, integer-nodes, or coefficients (unspecified convention)")
	fs.StringVar(&o.verifier, "verifier", "appendix-e", "appendix-e or section4-scalar (extra scalar diagnostic input)")
	fs.StringVar(&o.batchProduct, "batch-product", string(zkmap.LiteralBatch), "literal or scalar-evaluation (diagnostic interpretation)")
	fs.StringVar(&o.input, "input", "random", "random; zero is a test fixture only")
	fs.StringVar(&o.output, "output", "", "new JSONL file, never overwritten; default stdout")
	fs.BoolVar(&o.plan, "plan", false, "print workload metadata without allocation/setup")
	if e := fs.Parse(args); e != nil {
		return 1
	}
	if fs.NArg() != 0 {
		fmt.Fprintln(errOut, "unexpected positional arguments")
		return 1
	}
	if e := validate(o); e != nil {
		fmt.Fprintln(errOut, e)
		return 1
	}
	n := 1 << o.k
	q := max(o.batch, 1)
	if o.plan {
		e := json.NewEncoder(out).Encode(map[string]any{"n": n, "batch_q": q, "batch_mode": o.batch > 0, "repetitions": o.reps, "threads": o.threads, "variant": o.variant, "projection_encoding": o.encoding, "input_profile": o.input, "allocated": false, "setup_executed": false, "matrix_field_bytes": int64(3) * int64(n) * int64(n) * 32, "srs_g1_points": n * n, "max_matrix_elements": o.maxElements})
		if e != nil {
			fmt.Fprintln(errOut, e)
			return 1
		}
		return 0
	}
	runtime.GOMAXPROCS(o.threads)
	writer := out
	var f *os.File
	if o.output != "" {
		var e error
		f, e = os.OpenFile(o.output, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0644)
		if e != nil {
			fmt.Fprintln(errOut, e)
			return 1
		}
		defer f.Close()
		writer = f
	}
	source, e := sourceInfo()
	if e != nil {
		fmt.Fprintln(errOut, e)
		return 1
	}
	host := hostInfo()
	start := time.Now()
	var pp *zkmap.Params
	var complete *zkmap.CompleteParams
	if o.variant == zkmap.CompletenessVariant {
		complete, e = zkmap.SetupComplete(n, o.maxElements)
		if e == nil {
			pp = complete.Base()
		}
	} else {
		pp, e = zkmap.Setup(n, o.maxElements, zkmap.Encoding(o.encoding))
	}
	setupSeconds := time.Since(start).Seconds()
	if e != nil {
		r := map[string]any{"scheme": "zkmap", "status": "setup_failed", "error": e.Error(), "verification_succeeded": nil, "proof_generated": false, "setup_seconds": setupSeconds, "n": n, "host": host, "source": source}
		if e = json.NewEncoder(writer).Encode(r); e != nil {
			fmt.Fprintln(errOut, e)
			return 1
		}
		return 2
	}
	points, srsBytes := pp.SRSInfo()
	encoder := json.NewEncoder(writer)
	failed := false
	for repetition := 1; repetition <= o.reps; repetition++ {
		var r record
		if complete != nil {
			r = attemptComplete(complete, o, repetition)
		} else {
			r = attempt(pp, o, repetition)
		}
		r.Variant = o.variant
		r.Timings["setup"] = setupSeconds
		r.Host = host
		r.Source = source
		r.SRS = map[string]any{"mode": "single_party_experimental", "g1_points": points, "serialized_bytes": srsBytes, "sha256": pp.SRSDigest(), "compression": "none"}
		if complete != nil {
			r.SRS["g2_points"] = complete.G2Points()
		} else {
			r.SRS["g2_points"] = 2
		}
		if e := encoder.Encode(r); e != nil {
			fmt.Fprintln(errOut, e)
			return 1
		}
		fmt.Fprintf(errOut, "run %d/%d n=%d q=%d: %s\n", repetition, o.reps, n, q, r.Status)
		if r.Status != "verified" {
			failed = true
		}
	}
	if f != nil {
		if e := f.Sync(); e != nil {
			fmt.Fprintln(errOut, e)
			return 1
		}
	}
	if failed {
		return 2
	}
	return 0
}

func validate(o options) error {
	if o.variant != "paper" && o.variant != zkmap.CompletenessVariant {
		return fmt.Errorf("unknown variant")
	}
	if o.variant == zkmap.CompletenessVariant && (o.encoding != string(zkmap.Roots) || o.verifier != "appendix-e" || o.batchProduct != string(zkmap.LiteralBatch)) {
		return fmt.Errorf("completeness-roots-v1 requires roots-of-unity and does not use the paper verifier/batch-product override flags")
	}
	if o.k < 1 || o.k > 13 || o.reps < 1 || o.threads < 1 || o.batch < 0 || o.batch > 10000 || o.maxElements < 1 {
		return fmt.Errorf("invalid K/repetitions/threads/batch/element limit")
	}
	n := 1 << o.k
	if n*n > o.maxElements {
		return fmt.Errorf("n^2 exceeds max-matrix-elements")
	}
	if e := zkmap.Encoding(o.encoding).Validate(); e != nil {
		return e
	}
	if o.verifier != "appendix-e" && o.verifier != "section4-scalar" {
		return fmt.Errorf("unknown verifier")
	}
	if o.batchProduct != string(zkmap.LiteralBatch) && o.batchProduct != string(zkmap.ScalarBatch) {
		return fmt.Errorf("unknown batch product reading")
	}
	if o.input != "random" && o.input != "zero" {
		return fmt.Errorf("unknown input profile")
	}
	return nil
}

func attempt(pp *zkmap.Params, o options, repetition int) record {
	q := max(o.batch, 1)
	seed := o.seed + int64(repetition-1)*7919
	random := rand.New(rand.NewSource(seed))
	r := record{Schema: 1, Scheme: "zkmap", Fidelity: "published_equations_with_declared_conventions", Status: "verified", Workload: "square", N: pp.N(), BatchQ: q, Run: repetition, Seed: seed, Threads: o.threads, Encoding: o.encoding, Verifier: o.verifier, BatchProduct: o.batchProduct, Input: o.input, Timings: map[string]float64{}, LAMPReference: map[string]any{"rho": "1/2", "queries": 309, "applied_to_zkmap": false}, Accounting: "setup excluded; matrix_compute excluded; commit + attempted_prove includes projection/interpolation; failure timings are not successful proof timings"}
	if o.batch > 0 {
		r.Workload = "batch"
	}
	ss := make([]zkmap.Statement, q)
	proofs := make([]zkmap.Proof, q)
	traces := make([]*zkmap.Computation, q)
	allProofs := true
	allVerified := true
	allDecoded := true
	for i := 0; i < q; i++ {
		n := pp.N()
		var a, b zkmap.Matrix
		if o.input == "random" {
			a = zkmap.RandomMatrix(random, n, n)
			b = zkmap.RandomMatrix(random, n, n)
		} else {
			a = zkmap.Matrix{Rows: n, Cols: n, Data: makeZero(n * n)}
			b = zkmap.Matrix{Rows: n, Cols: n, Data: makeZero(n * n)}
		}
		start := time.Now()
		c, e := zkmap.Multiply(a, b)
		r.Timings["matrix_compute"] += time.Since(start).Seconds()
		if e != nil {
			r.Status = "input_error"
			r.Error = e.Error()
			return r
		}
		start = time.Now()
		s, e := zkmap.CommitMatrices(pp, a, b, c)
		r.Timings["matrix_commit"] += time.Since(start).Seconds()
		if e != nil {
			r.Status = "commit_failed"
			r.Error = e.Error()
			return r
		}
		ss[i] = s
		encodedStatement, e := s.MarshalBinary()
		if e != nil {
			r.Status = "serialization_error"
			r.Error = e.Error()
			return r
		}
		r.StatementBytes += len(encodedStatement)
		start = time.Now()
		proof, trace, e := zkmap.Prove(pp, s, a, b, c)
		r.Timings["attempted_prove"] += time.Since(start).Seconds()
		traces[i] = trace
		cr := claimRecord{Status: "proof_generated"}
		if trace != nil {
			cr.Challenge = trace.Y.String()
			cr.Remainder = trace.Remainder.String()
			cr.ProjectionIdentity = trace.Mu.Equal(&trace.InnerProduct)
		}
		if e != nil {
			allProofs = false
			allVerified = false
			cr.Status = "prove_failed"
			var rem *zkmap.WitnessRemainderError
			if errors.As(e, &rem) {
				cr.Status = "witness_remainder_nonzero"
			}
			cr.Error = e.Error()
			r.Claims = append(r.Claims, cr)
			if r.Status == "verified" {
				r.Status = cr.Status
				r.Error = cr.Error
			}
			continue
		}
		cr.ProofGenerated = true
		proofs[i] = *proof
		if o.batch == 0 {
			verify := func(s zkmap.Statement, p zkmap.Proof) error {
				if o.verifier == "appendix-e" {
					return zkmap.VerifyAppendixE(pp, s, p)
				}
				return zkmap.VerifySection4Scalar(pp, s, p, trace.AEval, trace.BEval)
			}
			start = time.Now()
			e = verify(s, *proof)
			r.Timings["verify"] += time.Since(start).Seconds()
			accepted := e == nil
			cr.Verification = &accepted
			r.Verification = &accepted
			if e != nil {
				allVerified = false
				cr.Status = "verification_rejected"
				cr.Error = e.Error()
				r.Status = cr.Status
				r.Error = cr.Error
			} else {
				cr.Status = "verified"
			}
			payload, wireErr := proof.MarshalBinary()
			if wireErr != nil {
				r.Status = "serialization_error"
				r.Error = wireErr.Error()
				return r
			}
			size := len(payload)
			r.ProofBytes = &size
			ds, wireErr := zkmap.UnmarshalStatement(encodedStatement)
			if wireErr != nil {
				r.Status = "serialization_error"
				r.Error = wireErr.Error()
				return r
			}
			dp, wireErr := zkmap.UnmarshalProof(payload)
			if wireErr != nil {
				r.Status = "serialization_error"
				r.Error = wireErr.Error()
				return r
			}
			if o.verifier == "section4-scalar" {
				context := zkmap.MarshalScalarContext(trace.AEval, trace.BEval)
				r.ContextBytes = len(context)
				av, bv, wireErr := zkmap.UnmarshalScalarContext(context)
				if wireErr != nil {
					r.Status = "serialization_error"
					r.Error = wireErr.Error()
					return r
				}
				allDecoded = zkmap.VerifySection4Scalar(pp, ds, dp, av, bv) == nil
			} else {
				allDecoded = verify(ds, dp) == nil
			}
		}
		r.Claims = append(r.Claims, cr)
	}
	r.Timings["attempted_full_online_prove"] = r.Timings["matrix_commit"] + r.Timings["attempted_prove"]
	r.ProofGenerated = allProofs
	if !allProofs {
		return r
	}
	if o.batch == 0 {
		r.PayloadReverified = &allDecoded
		if allVerified && !allDecoded {
			r.Status = "decoded_payload_rejected"
		}
		return r
	}
	// The four-point batch tuple omits individual commitments, challenges and rho.
	// Count the supplied statement context and rho rather than hiding their cost.
	rho, e := zkmap.SampleRho()
	if e != nil {
		r.Status = "randomness_failed"
		r.Error = e.Error()
		return r
	}
	r.ContextBytes = 32
	start := time.Now()
	bp, e := zkmap.Aggregate(pp, ss, proofs, traces, rho, zkmap.BatchProduct(o.batchProduct))
	r.Timings["attempted_aggregate"] = time.Since(start).Seconds()
	r.Timings["attempted_full_online_prove"] += r.Timings["attempted_aggregate"]
	if e != nil {
		r.ProofGenerated = false
		r.Status = "batch_aggregation_failed"
		r.Error = e.Error()
		return r
	}
	if o.batchProduct == string(zkmap.ScalarBatch) {
		r.AggregateInputs = 64 * q
	}
	start = time.Now()
	e = zkmap.VerifyBatch(pp, ss, bp, rho)
	r.Timings["verify"] = time.Since(start).Seconds()
	accepted := e == nil
	r.Verification = &accepted
	if e != nil {
		r.Status = "verification_rejected"
		r.Error = e.Error()
	}
	payload, e := bp.MarshalBinary()
	if e != nil {
		r.Status = "serialization_error"
		r.Error = e.Error()
		return r
	}
	size := len(payload)
	r.ProofBytes = &size
	ds := make([]zkmap.Statement, q)
	for i, s := range ss {
		b, e := s.MarshalBinary()
		if e != nil {
			r.Status = "serialization_error"
			r.Error = e.Error()
			return r
		}
		ds[i], e = zkmap.UnmarshalStatement(b)
		if e != nil {
			r.Status = "serialization_error"
			r.Error = e.Error()
			return r
		}
	}
	dp, e := zkmap.UnmarshalBatchProof(payload)
	if e != nil {
		r.Status = "serialization_error"
		r.Error = e.Error()
		return r
	}
	allDecoded = zkmap.VerifyBatch(pp, ds, dp, rho) == nil
	r.PayloadReverified = &allDecoded
	if accepted && !allDecoded {
		r.Status = "decoded_payload_rejected"
	}
	return r
}

// A fingerprint of the actual module files accompanies Git HEAD, which alone
// would omit these uncommitted implementation files. The executable hash is
// included as well; raw output/input data is not hashed into the source digest.
func sourceInfo() (map[string]any, error) {
	root, e := moduleRoot()
	if e != nil {
		return nil, e
	}
	h := sha256.New()
	count := 0
	e = filepath.WalkDir(root, func(path string, d os.DirEntry, walkErr error) error {
		if walkErr != nil {
			return walkErr
		}
		if d.IsDir() {
			if d.Name() == "bin" || d.Name() == "results" {
				return filepath.SkipDir
			}
			return nil
		}
		if filepath.Ext(path) != ".go" && d.Name() != "go.mod" && d.Name() != "go.sum" {
			return nil
		}
		relative, e := filepath.Rel(root, path)
		if e != nil {
			return e
		}
		b, e := os.ReadFile(path)
		if e != nil {
			return e
		}
		h.Write([]byte(filepath.ToSlash(relative)))
		h.Write([]byte{0})
		h.Write(b)
		count++
		return nil
	})
	if e != nil {
		return nil, e
	}
	result := map[string]any{"source_tree_sha256": hex.EncodeToString(h.Sum(nil)), "source_files_hashed": count, "scope": "module Go source, go.mod and go.sum", "paper_sha256": "43e9631792b3c6124e58f081c11073113d779794e1fb0d4ab97aa5cac99ceaec"}
	if b, e := exec.Command("git", "-C", root, "rev-parse", "HEAD").Output(); e == nil {
		result["git_head"] = strings.TrimSpace(string(b))
	}
	if exe, e := os.Executable(); e == nil {
		f, e := os.Open(exe)
		if e == nil {
			defer f.Close()
			bh := sha256.New()
			if _, e = io.Copy(bh, f); e == nil {
				result["binary_sha256"] = hex.EncodeToString(bh.Sum(nil))
			}
		}
	}
	if info, ok := debug.ReadBuildInfo(); ok {
		result["build_info"] = info.String()
	}
	return result, nil
}
func moduleRoot() (string, error) {
	cwd, e := os.Getwd()
	if e != nil {
		return "", e
	}
	for dir := cwd; ; dir = filepath.Dir(dir) {
		if b, e := os.ReadFile(filepath.Join(dir, "go.mod")); e == nil && strings.HasPrefix(string(b), "module example.com/lamp-zkmap") {
			return dir, nil
		}
		if filepath.Dir(dir) == dir {
			break
		}
	}
	return "", fmt.Errorf("run zkmap from its Implementation/zkmap module directory so source fingerprint is available")
}
func hostInfo() map[string]any {
	cpu := "unknown"
	var memoryBytes any
	var osDescription any
	if runtime.GOOS == "darwin" {
		if b, e := exec.Command("sysctl", "-n", "machdep.cpu.brand_string").Output(); e == nil {
			cpu = strings.TrimSpace(string(b))
		}
		if b, e := exec.Command("sysctl", "-n", "hw.memsize").Output(); e == nil {
			if n, e := strconv.ParseUint(strings.TrimSpace(string(b)), 10, 64); e == nil {
				memoryBytes = n
			}
		}
		if b, e := exec.Command("sw_vers", "-productVersion").Output(); e == nil {
			osDescription = strings.TrimSpace(string(b))
		}
	} else if b, e := os.ReadFile("/proc/cpuinfo"); e == nil {
		for _, line := range strings.Split(string(b), "\n") {
			if strings.HasPrefix(line, "model name") {
				parts := strings.SplitN(line, ":", 2)
				if len(parts) == 2 {
					cpu = strings.TrimSpace(parts[1])
					break
				}
			}
		}
	}
	if runtime.GOOS == "linux" {
		if b, e := os.ReadFile("/proc/meminfo"); e == nil {
			for _, line := range strings.Split(string(b), "\n") {
				if strings.HasPrefix(line, "MemTotal:") {
					f := strings.Fields(line)
					if len(f) >= 2 {
						if n, e := strconv.ParseUint(f[1], 10, 64); e == nil {
							memoryBytes = n * 1024
						}
					}
					break
				}
			}
		}
		if b, e := os.ReadFile("/etc/os-release"); e == nil {
			osDescription = string(b)
		}
	}
	return map[string]any{"cpu": cpu, "memory_bytes": memoryBytes, "os_description": osDescription, "goos": runtime.GOOS, "goarch": runtime.GOARCH, "go_version": runtime.Version(), "runtime_num_cpu": runtime.NumCPU(), "gomaxprocs": runtime.GOMAXPROCS(0)}
}
