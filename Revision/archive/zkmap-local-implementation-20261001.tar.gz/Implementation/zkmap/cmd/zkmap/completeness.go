package main

import (
	"example.com/lamp-zkmap/zkmap"
	"math/rand"
	"time"
)

func attemptComplete(cp *zkmap.CompleteParams, o options, repetition int) record {
	pp := cp.Base()
	q := max(o.batch, 1)
	seed := o.seed + int64(repetition-1)*7919
	random := rand.New(rand.NewSource(seed))
	r := record{Schema: 1, Scheme: "zkmap", Variant: zkmap.CompletenessVariant, Fidelity: "local_completeness_variant_not_published_zkmap", Status: "verified", Workload: "square", N: pp.N(), BatchQ: q, Run: repetition, Seed: seed, Threads: o.threads, Encoding: string(zkmap.Roots), Verifier: "roots-inner-product-identity", BatchProduct: "weighted-product-pairings", Input: o.input, Timings: map[string]float64{}, LAMPReference: map[string]any{"rho": "1/2", "queries": 309, "applied_to_zkmap": false}, Accounting: "setup and matrix_compute excluded; matrix_commit + prove includes interpolation and new G2 commitment; functional test times are not comparative benchmarks"}
	if o.batch > 0 {
		r.Workload = "batch"
	}
	ss := make([]zkmap.Statement, q)
	proofs := make([]zkmap.CompleteProof, q)
	allProofs := true
	for i := 0; i < q; i++ {
		n := pp.N()
		var a, b zkmap.Matrix
		if o.input == "random" {
			a = zkmap.RandomMatrix(random, n, n)
			b = zkmap.RandomMatrix(random, n, n)
		} else {
			a = zkmap.Matrix{Rows: n, Cols: n, Data: makeZero(n * n)}
			b = zkmap.Matrix{Rows: n, Cols: n, Data: makeZero(n * n)}
		}
		start := time.Now()
		c, e := zkmap.Multiply(a, b)
		r.Timings["matrix_compute"] += time.Since(start).Seconds()
		if e != nil {
			r.Status = "input_error"
			r.Error = e.Error()
			return r
		}
		start = time.Now()
		s, e := zkmap.CommitMatrices(pp, a, b, c)
		r.Timings["matrix_commit"] += time.Since(start).Seconds()
		if e != nil {
			r.Status = "commit_failed"
			r.Error = e.Error()
			return r
		}
		ss[i] = s
		encodedStatement, e := s.MarshalBinary()
		if e != nil {
			r.Status = "serialization_error"
			r.Error = e.Error()
			return r
		}
		r.StatementBytes += len(encodedStatement)
		start = time.Now()
		proof, trace, e := zkmap.ProveComplete(cp, s, a, b, c)
		r.Timings["prove"] += time.Since(start).Seconds()
		cr := claimRecord{Status: "proof_generated"}
		if trace != nil {
			cr.Challenge = trace.Y.String()
			cr.Remainder = trace.ConstantRemainder.String()
			cr.ProjectionIdentity = trace.Mu.Equal(&trace.InnerProduct)
		}
		if e != nil {
			allProofs = false
			cr.Status = "completeness_prove_failed"
			cr.Error = e.Error()
			r.Status = cr.Status
			r.Error = cr.Error
			r.Claims = append(r.Claims, cr)
			continue
		}
		cr.ProofGenerated = true
		proofs[i] = *proof
		if o.batch == 0 {
			start = time.Now()
			e = zkmap.VerifyComplete(cp, s, *proof)
			r.Timings["verify"] = time.Since(start).Seconds()
			accepted := e == nil
			cr.Verification = &accepted
			r.Verification = &accepted
			if e != nil {
				r.Status = "verification_rejected"
				r.Error = e.Error()
				cr.Status = r.Status
				cr.Error = r.Error
			} else {
				cr.Status = "verified"
			}
			payload, e := proof.MarshalBinary()
			if e != nil {
				r.Status = "serialization_error"
				r.Error = e.Error()
				return r
			}
			size := len(payload)
			r.ProofBytes = &size
			ds, e := zkmap.UnmarshalStatement(encodedStatement)
			if e != nil {
				r.Status = "serialization_error"
				r.Error = e.Error()
				return r
			}
			dp, e := zkmap.UnmarshalCompleteProof(payload)
			if e != nil {
				r.Status = "serialization_error"
				r.Error = e.Error()
				return r
			}
			decodedAccepted := zkmap.VerifyComplete(cp, ds, dp) == nil
			r.PayloadReverified = &decodedAccepted
			if accepted && !decodedAccepted {
				r.Status = "decoded_payload_rejected"
			}
		}
		r.Claims = append(r.Claims, cr)
	}
	r.Timings["full_online_prove"] = r.Timings["matrix_commit"] + r.Timings["prove"]
	r.ProofGenerated = allProofs
	if !allProofs || o.batch == 0 {
		return r
	}
	rho, e := zkmap.SampleRho()
	if e != nil {
		r.Status = "randomness_failed"
		r.Error = e.Error()
		return r
	}
	r.ContextBytes = 32
	start := time.Now()
	bp, e := zkmap.AggregateComplete(cp, proofs, rho)
	r.Timings["aggregate"] = time.Since(start).Seconds()
	r.Timings["full_online_prove"] += r.Timings["aggregate"]
	if e != nil {
		r.Status = "batch_aggregation_failed"
		r.Error = e.Error()
		r.ProofGenerated = false
		return r
	}
	start = time.Now()
	e = zkmap.VerifyCompleteBatch(cp, ss, *bp, rho)
	r.Timings["verify"] = time.Since(start).Seconds()
	accepted := e == nil
	r.Verification = &accepted
	if e != nil {
		r.Status = "verification_rejected"
		r.Error = e.Error()
	}
	payload, e := bp.MarshalBinary()
	if e != nil {
		r.Status = "serialization_error"
		r.Error = e.Error()
		return r
	}
	size := len(payload)
	r.ProofBytes = &size
	ds := make([]zkmap.Statement, q)
	for i, s := range ss {
		encoded, e := s.MarshalBinary()
		if e != nil {
			r.Status = "serialization_error"
			r.Error = e.Error()
			return r
		}
		ds[i], e = zkmap.UnmarshalStatement(encoded)
		if e != nil {
			r.Status = "serialization_error"
			r.Error = e.Error()
			return r
		}
	}
	dp, e := zkmap.UnmarshalCompleteBatchProof(payload)
	if e != nil {
		r.Status = "serialization_error"
		r.Error = e.Error()
		return r
	}
	decodedAccepted := zkmap.VerifyCompleteBatch(cp, ds, dp, rho) == nil
	r.PayloadReverified = &decodedAccepted
	if accepted && !decodedAccepted {
		r.Status = "decoded_payload_rejected"
	}
	return r
}
