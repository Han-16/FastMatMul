import importlib.util
import json
from pathlib import Path
import unittest
from unittest import mock
import tempfile

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("runner", HERE / "run_section7.py")
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)


class Section7PlanTests(unittest.TestCase):
    def test_exact_paper_sizes_and_independent_batches(self):
        config = json.loads((HERE / "section7_profiles.json").read_text())
        plan = runner.make_plan(config, "both", Path("/tmp/zkmap"))
        self.assertEqual(len(plan["commands"]), 17)
        self.assertEqual([c["n"] for c in plan["commands"][:7]], [128, 256, 512, 1024, 2048, 4096, 8192])
        self.assertEqual([c["batch_q"] for c in plan["commands"][7:]], list(range(1, 11)))
        for c in plan["commands"]:
            cmd = c["command"]
            self.assertEqual(cmd[cmd.index("-repetitions") + 1], "10")
            self.assertEqual(cmd[cmd.index("-threads") + 1], "32")
            self.assertEqual(cmd[cmd.index("-input") + 1], "random")
            self.assertEqual(cmd[cmd.index("-max-matrix-elements") + 1], str(c["n"] ** 2))
        self.assertFalse(plan["executed"])
        self.assertFalse(plan["lamp_reference_parameters"]["applied_to_zkmap"])
        self.assertEqual(sum(g["count"] for g in plan["gpt2"]["groups"]), 36)
        self.assertFalse(plan["gpt2"]["execution_supported"])

    def test_failed_preflight_never_runs_large_workloads(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            binary = root / "binary"
            binary.write_bytes(b"not executed")
            output = root / "results"
            args = ["run_section7.py", "--execute", "--binary", str(binary), "--output", str(output)]
            with mock.patch("sys.argv", args), mock.patch("os.cpu_count", return_value=32), mock.patch.object(runner, "call", return_value=2) as call:
                self.assertEqual(runner.main(), 2)
            self.assertEqual(call.call_count, 1)
            summary = json.loads((output / "execution.json").read_text())
            self.assertFalse(summary["large_workloads_executed"])

    def test_explicit_failure_reproduction_preserves_all_targets(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            binary = root / "binary"
            binary.write_bytes(b"not executed")
            output = root / "results"
            args = ["run_section7.py", "--execute", "--allow-failed-attempts", "--binary", str(binary), "--output", str(output)]
            with mock.patch("sys.argv", args), mock.patch("os.cpu_count", return_value=32), mock.patch.object(runner, "call", return_value=2) as call:
                self.assertEqual(runner.main(), 2)
            self.assertEqual(call.call_count, 18)  # one preflight plus 17 targets
            summary = json.loads((output / "execution.json").read_text())
            self.assertEqual(len(summary["runs"]), 17)
            self.assertTrue(all(r["exit_code"] == 2 for r in summary["runs"]))


if __name__ == "__main__":
    unittest.main()
