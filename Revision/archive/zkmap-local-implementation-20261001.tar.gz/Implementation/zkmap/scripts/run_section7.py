#!/usr/bin/env python3
"""Section 7 zkMaP attempts. Default: print plan only, without setup or execution."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
PROFILE = Path(__file__).with_name("section7_profiles.json")


def make_plan(config, profile, binary, encoding=None, verifier=None, batch_product=None):
    commands = []
    targets = []
    if profile in ("square", "both"):
        targets.extend((k, 0) for k in config["square_log_k"])
    if profile in ("batch", "both"):
        targets.extend((config["batch_log_k"], q) for q in config["batch_q"])
    for k, q in targets:
        command = [str(binary), "-K", str(k), "-repetitions", str(config["repetitions"]),
                   "-threads", str(config["threads"]), "-seed", str(config["seed"]),
                   "-max-matrix-elements", str((1 << k) ** 2),
                   "-projection-encoding", encoding or config["projection_encoding"],
                   "-verifier", verifier or config["verifier"],
                   "-batch-product", batch_product or config["batch_product"], "-input", "random"]
        if q:
            command.extend(["-batch", str(q)])
        commands.append({"name": f"{'batch' if q else 'square'}_k{k}_q{max(q, 1)}",
                         "n": 1 << k, "batch_q": max(q, 1), "command": command})
    return {"profile": profile, "cwd": str(ROOT), "executed": False,
            "profile_sha256": hashlib.sha256(PROFILE.read_bytes()).hexdigest(),
            "runner_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "lamp_reference_parameters": config["lamp_reference_parameters"],
            "success_measurements_available": False,
            "note": "Failure attempts are not successful prover/verifier benchmarks. Setup and actual AB computation are measured separately.",
            "commands": commands, "gpt2": config["gpt2"]}


def call(command, directory):
    with (directory / "stdout.txt").open("x") as out, (directory / "stderr.txt").open("x") as err:
        result = subprocess.run(command, cwd=ROOT, stdout=out, stderr=err)
    return result.returncode


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--profile", choices=("square", "batch", "both", "gpt2"), default="both")
    parser.add_argument("--binary", type=Path, default=ROOT / "bin/zkmap")
    parser.add_argument("--plan", action="store_true", help="explicitly select plan-only mode")
    parser.add_argument("--execute", action="store_true", help="run a preflight and selected workloads locally")
    parser.add_argument("--output", type=Path, help="new results directory, required for execution")
    parser.add_argument("--projection-encoding", choices=("roots-of-unity", "integer-nodes", "coefficients"))
    parser.add_argument("--verifier", choices=("appendix-e", "section4-scalar"))
    parser.add_argument("--batch-product", choices=("literal", "scalar-evaluation"))
    parser.add_argument("--allow-failed-attempts", action="store_true", help="continue full-size attempts even when small normal-input preflight fails")
    args = parser.parse_args()
    if args.plan and args.execute:
        parser.error("--plan and --execute cannot be combined")
    config = json.loads(PROFILE.read_text())
    binary = args.binary.resolve()
    plan = make_plan(config, args.profile, binary, args.projection_encoding, args.verifier, args.batch_product)
    if not args.execute:
        print(json.dumps(plan, indent=2))
        return 0
    if args.profile == "gpt2":
        parser.error("GPT-2 shapes are inventoried but no faithful executable specification is available")
    if args.output is None:
        parser.error("--execute requires a new --output directory")
    if not binary.is_file():
        parser.error("build bin/zkmap first with go build -o bin/zkmap ./cmd/zkmap")
    if config["threads"] > (__import__("os").cpu_count() or 1):
        parser.error("this Section 7 profile requires at least 32 available logical CPUs")
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    plan["binary_sha256"] = hashlib.sha256(binary.read_bytes()).hexdigest()
    (output / "plan.json").write_text(json.dumps(plan, indent=2) + "\n")
    preflight = output / "preflight"
    preflight.mkdir()
    command = list(plan["commands"][0]["command"])
    for flag, value in (("-K", "2"), ("-repetitions", "1"), ("-max-matrix-elements", "16")):
        command[command.index(flag) + 1] = value
    # Batch profiles must preflight a batch as well as individual proof creation.
    if "-batch" in command:
        command[command.index("-batch") + 1] = "2"
    command.extend(["-output", str(preflight / "attempts.jsonl")])
    preflight_code = call(command, preflight)
    if preflight_code not in (0, 2):
        (output / "execution.json").write_text(json.dumps({"status": "preflight_execution_error", "exit_code": preflight_code}) + "\n")
        return 1
    if preflight_code == 2 and not args.allow_failed_attempts:
        (output / "execution.json").write_text(json.dumps({"status": "preflight_protocol_failure", "large_workloads_executed": False,
            "note": "Exact published witness/verification failed. Inspect preflight; --allow-failed-attempts explicitly selects full-size failure reproduction."}, indent=2) + "\n")
        print("Preflight failed; no full-size workload executed.", file=sys.stderr)
        return 2
    results = []
    for item in plan["commands"]:
        directory = output / item["name"]
        directory.mkdir()
        command = item["command"] + ["-output", str(directory / "attempts.jsonl")]
        code = call(command, directory)
        results.append({"name": item["name"], "command": command, "exit_code": code})
        # Infrastructure/program failure is distinct from a published equation failure.
        if code not in (0, 2):
            break
    (output / "execution.json").write_text(json.dumps({"preflight_exit_code": preflight_code, "runs": results}, indent=2) + "\n")
    return 0 if all(r["exit_code"] == 0 for r in results) else 2


if __name__ == "__main__":
    raise SystemExit(main())
